#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
from scipy import stats

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2
version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='utf8')
cursor = conn.cursor()


version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']
num_com = []
all_cmm = []
com_cmm_list = []
for i in range(14):
    start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
    end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
    print start_time, end_time
    cursor.execute("SELECT count(distinct company) "
                   "FROM scmlog, commits_lines, repositories "
                   "where company is not null "
                   "and message not like '    Merge %%' "
                   "and date between %s and %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null ", (start_time, end_time))
    res1 = cursor.fetchall()
    num_com.append(res1[0][0])

    cursor.execute("SELECT count(distinct scmlog.id) "
                   "FROM scmlog, commits_lines, repositories "
                   "where company not like 'independent' "
                   "and message not like '    Merge %%' "
                   "and date between %s and %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null ", (start_time, end_time))
    res2 = cursor.fetchall()
    all_cmm.append(res2[0][0])

    cursor.execute("SELECT company, count(distinct scmlog.id) "
                   "FROM scmlog, commits_lines, repositories "
                   "where company not like 'independent' "
                   "and message not like '    Merge %%' "
                   "and date between %s and %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null "
                   "group by company "
                   "order by count(distinct id) desc", (start_time, end_time))
    res3 = cursor.fetchall()
    com_cmm_list.append(res3)

sum_7 = []
for i in range(14):
    sum = 0
    for j in range(int(len(com_cmm_list[i])*0.07)):
        sum += com_cmm_list[i][j][1]
    sum_7.append(sum)

print 'com_cmm_list', com_cmm_list
print 'sum_7', sum_7
print 'all_cmm', all_cmm
np.savetxt(path2 + "/data/num_com.csv", num_com, fmt="%d", delimiter=",")
np.savetxt(path2 + "/data/sum_7.csv", sum_7, fmt="%d", delimiter=",")
np.savetxt(path2 + "/data/com_cmm_version.csv", com_cmm_list, fmt="%s", delimiter=",")

idp_cmm_ratio = [0.132513015, 0.149925037, 0.113375796, 0.104435326, 0.083070566, 0.053032163,
                 0.045035824, 0.066932483, 0.044618682, 0.053196222, 0.045107473, 0.053400117,
                 0.060775089, 0.054308554]

concentration_ratio = [0.25, 0.241379, 0.269231, 0.136364, 0.119403, 0.141176, 0.092308, 0.075145,
                       0.093023, 0.073684, 0.058577, 0.054475, 0.063492, 0.05597]
corr, p_val = stats.pearsonr(idp_cmm_ratio, concentration_ratio)
print 'corr', corr
print 'p_val', p_val

conn.commit()
cursor.close()
conn.close()