#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division

import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

version = range(1, 15)
print 'version: ', version


# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            dataList.append(tmpList)
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList


# 变换数据格式
def change_formate(dataset):
    temp = []
    for i in range(len(dataset)):
        if len(dataset[i]) == 1:
            if "." in dataset[i][0]:
                value = float(dataset[i][0])
            else:
                value = int(dataset[i][0])
            print value
        else:
            value = []
            for j in range(len(dataset[i])):
                if dataset[i][j].isdigit():
                    if "." in dataset[i][j]:
                        value.append(float(dataset[i][j]))
                    else:
                        value.append(int(dataset[i][j]))
                else:
                    value.append(dataset[i][j])
        temp.append(value)
    return temp


com_commit = readListCSV(path2 + "/data/com_commit.csv")
com_manpower = readListCSV(path2 + "/data/com_manpower.csv")
coms_commits = readListCSV(path2 + "/data/coms_commits.csv")
coms_manpower = readListCSV(path2 + "/data/coms_manpower.csv")
idp_commit = readListCSV(path2 + "/data/idp_commit.csv")
idp_manpower = readListCSV(path2 + "/data/idp_manpower.csv")
domination_commits = readListCSV(path2 + "/data/domination_commits.csv")
domination_manpower = readListCSV(path2 + "/data/domination_manpower.csv")
shang_commits = readListCSV(path2 + "/data/shang_commits.csv")
shang_manpower = readListCSV(path2 + "/data/shang_manpower.csv")
num_com_commit = readListCSV(path2 + "/data/num_com_commit.csv")
num_com_manpower = readListCSV(path2 + "/data/num_com_manpower.csv")
num_company = readListCSV(path2 + "/data/num_company.csv")

com_commit = change_formate(com_commit)
com_manpower = change_formate(com_manpower)
coms_commits = change_formate(coms_commits)
coms_manpower = change_formate(coms_manpower)
idp_commit = change_formate(idp_commit)
idp_manpower = change_formate(idp_manpower)
domination_commits = change_formate(domination_commits)
domination_manpower = change_formate(domination_manpower)
shang_commits = change_formate(shang_commits)
shang_manpower = change_formate(shang_manpower)
num_com_commit = change_formate(num_com_commit)
num_com_manpower = change_formate(num_com_manpower)
num_company = change_formate(num_company)

print 'com_manpower: ', com_manpower
print 'idp_manpower: ', idp_manpower
print 'com_commit: ', com_commit
print 'idp_commit: ', idp_commit
print 'num_com_manpower: ', num_com_manpower
print 'num_com_commit: ', num_com_commit
print 'coms_commits: ', coms_commits
print 'coms_manpower: ', coms_manpower
print 'shang_manpower: ', shang_manpower
print 'shang_commits: ', shang_commits
print 'domination_manpower: ', domination_manpower
print 'domination_commits: ', domination_commits
print 'num_company: ', num_company

com_commit1 = np.array(com_commit)
com_manpower1 = np.array(com_manpower)
idp_commit1 = np.array(idp_commit)
idp_manpower1 = np.array(idp_manpower)

com_per_commit = com_commit1 / com_manpower1
idp_per_commit = idp_commit1 / idp_manpower1
print 'com_per_commit: ', com_per_commit
print 'idp_per_commit: ', idp_per_commit
print 'mean(com_per_commit)', mean(com_per_commit)
print 'median(com_per_commit)', median(com_per_commit)
print 'mean(idp_per_commit)', mean(idp_per_commit)
print 'median(idp_per_commit)', median(idp_per_commit)
print 'mean(idp_manpower)', mean(idp_manpower)
print 'median(idp_manpower)', median(idp_manpower)
print 'mean(com_manpower)', mean(com_manpower)
print 'median(com_manpower)', median(com_manpower)


def percent(com, idp):
    # mean = 0
    # medium = 0
    percents = []
    for i in range(len(com)):
        percents.append(com[i] / (com[i] + idp[i]))
    print 'percents: ', percents
    # print mean(percents), median(percents)
    return mean(percents), median(percents)


mean_commits, medium_commits = percent(com_commit, idp_commit)
mean_manpower, medium_manpower = percent(com_manpower, idp_manpower)

print 'mean_commits, medium_commits', mean_commits, medium_commits
print 'mean_manpower, medium_manpower', mean_manpower, medium_manpower

# 绘制熵值和主导力度的曲线图
shang_std = []
for i in range(14):
    shang_std.append(math.log(num_company[i], 2))
print 'shang_std', shang_std


def plot_scatter(X, Y1, Y2, std, title, label1, label2, flag):
    # plt.figure(figsize=(6, 4))
    plt.plot(X, Y1, color="green", label=label1, linewidth=2)
    plt.plot(X, Y2, color="red", label=label2, linewidth=2)
    if flag == 1:
        plt.plot(X, std, color="blue", label="Standard Entropy", linewidth=2)
    plt.legend()  # 绘制图例
    path = path2 + "/figure/" + title + ".png"
    plt.savefig(path)
    plt.show()


plot_scatter(version, shang_manpower, shang_commits, shang_std,
             'Curve of entropy in developers and commits',
             'Developer Entropy', 'Commits Entropy', 0)

plot_scatter(version, domination_manpower, domination_commits, shang_std,
             'Curve of domination in developers and commits',
             'Developer Domination', 'Commits Domination', 0)

fig, ax = plt.subplots()
index = np.arange(14)
bar_width = 0.35
opacity = 0.4
com = plt.bar(index, com_manpower, bar_width, alpha=opacity, color='b', label='Companies')
idp = plt.bar(index + bar_width, idp_manpower, bar_width, alpha=opacity, color='r', label='Volunteer')
plt.xlabel('Version')
plt.ylabel('Number of developers')
plt.title('The number of developers from companies and volunteers in OpenStack')
plt.xticks(index + bar_width, ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14'))
plt.ylim(0, 2500)
plt.legend()
plt.tight_layout()
path = path2 + "/figure/" + "The number of developers from companies and volunteers in OpenStack.png"
plt.savefig(path)
plt.show()

# fig, ax = plt.subplots()
index = np.arange(14)
bar_width = 0.35
opacity = 0.4
com = plt.bar(index, com_commit, bar_width, alpha=opacity, color='b', label='Companies')
idp = plt.bar(index + bar_width, idp_commit, bar_width, alpha=opacity, color='r', label='Volunteer')
plt.xlabel('Version')
plt.ylabel('Number of commits')
plt.title('The number of commits from companies and volunteers in OpenStack')
plt.xticks(index + bar_width, ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14'))
plt.ylim(0, 42200)
plt.legend()
plt.tight_layout()
path = path2 + "/figure/" + "The number of commits from companies and volunteers in OpenStack.png"
plt.savefig(path)
plt.show()


def pie(coms, title):
    labels = []
    quants = []
    others = 0
    num_other_com = 0
    for i in range(len(coms)):
        if i < 9:
            labels.append(coms[i][0])
            quants.append(coms[i][1])
        else:
            others += int(coms[i][1])
            num_other_com = num_other_com + 1
    quants.append(others)
    labels.append(('others (#companies: ' + str(num_other_com) + ')'))

    print 'quants: ', quants
    print 'labels: ', labels

    # make a square figure
    plt.figure(1, figsize=(6, 6))
    plt.pie(quants, labels=labels)
    plt.title(title)
    path = path2 + "/figure/" + title + ".png"
    plt.savefig(path)
    plt.show()


pie(coms_commits, 'The commits contributed by companies to OpenStack')
pie(coms_manpower, 'The developers contributed by companies to OpenStack')


# 计算做80%贡献的公司占多大比例
percent_80_commit = []
percent_80_manpower = []


def percent_80(ver_data, total):
    sum = 0
    count = 0
    all_com = len(ver_data)
    print ver_data
    print len(ver_data)
    print total
    for i in range(len(ver_data)):
        if sum > 0.8 * total:
            break
        else:
            sum += int(ver_data[i])
            count += 1
    percent = count / all_com
    print 'percent:', percent
    return percent


def percent_28(dataset, com, idp):
    result = []
    for i in range(14):
        version_data = []
        for j in range(len(dataset)):
            if dataset[j][0] > i + 1:
                print version_data
                result.append(percent_80(version_data, com[i]+idp[i]))
                break
            elif dataset[j][0] == i + 1:
                version_data.append(dataset[j][2])
            else:
                continue
        if i == 13:
            result.append(percent_80(version_data, com[i] + idp[i]))
    return result

percent_80_commit = percent_28(num_com_commit, com_commit, idp_commit)
percent_80_manpower = percent_28(num_com_manpower, com_manpower, idp_manpower)
print 'percent_80_commit', percent_80_commit
print 'percent_80_manpower', percent_80_manpower


np.savetxt(path2 + "/data/28_cmm.csv", percent_80_commit, fmt="%f", delimiter=",")
np.savetxt(path2 + "/data/28_devp.csv", percent_80_manpower, fmt="%f", delimiter=",")


plot_scatter(version, percent_80_commit, percent_80_manpower, shang_std,
             'Fraction of companies who are responsible for 80% commits or developers',
             'Commits', 'Developer', 0)

print '********************************'
print 'mean(percent_80_commit)', mean(percent_80_commit)
print 'median(percent_80_commit)', median(percent_80_commit)
print '********************************'
print 'mean(percent_80_manpower)', mean(percent_80_manpower)
print 'median(percent_80_manpower)', median(percent_80_manpower)
