#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division

import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import git
from git import Repo
import pandas as pd
from io import StringIO

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
''' 克隆代码库
with open(path2 + "/data/projects.csv") as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        print(row['Project'], row['Repo_link'])
        git_url = row['Repo_link']
        repo_dir = 'D:\work\OpenStack_data' + '\\' + row['Project']
        print 'git_url', git_url
        print 'repo_dir', repo_dir
        repo = Repo.clone_from(git_url, repo_dir)
        #g = git.Git("C:/path/to/your/repo")

        log = repo.log('--since=2013-09-01', '--author=KIM BASINGER', '--pretty=tformat:', '--numstat')
        print log
        git log - -pretty = format:"%cn committed %h on %cd"
        '''
# Repo.clone_from(git_url, repo_dir)
'''
'''

repo = git.Git("D:/work/OpenStack_data/nova")
#log = repo.log('--decorate=full', '--simplify-by-decoration', '--pretty=%H|%aN|%ae|%ai|%d',
               #'HEAD')
log = repo.log('--date=format:%Y-%m-%d %H:%M:%S', '--shortstat', '--no-merges', '--decorate', '--simplify-by-decoration',
               '--pretty=%H|%aN|%ae|%ad|%cn|%ce|%cd|%s|%d').split('\n')
print type(log)
print len(log)
print log[1]


