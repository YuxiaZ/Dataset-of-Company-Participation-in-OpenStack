#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='zhangyuxia23',
                       db='openstack_sourcecode', charset='utf8')
cursor = conn.cursor()

start_time = datetime.date(datetime.strptime('2016-04-07', '%Y-%m-%d'))
end_time = datetime.date(datetime.strptime('2016-10-06', '%Y-%m-%d'))

# 获取newtone版本参与开发的公司列表
cursor.execute("SELECT company, count(distinct repository_id) as numP, count(distinct scmlog.id) as numC, "
               "count(distinct repositories.new_type) as numT "
               "FROM scmlog, commits_lines, repositories "
               "where date between %s and %s "
               "and message not like '    Merge %%' "
               "and company is not null "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "and repositories.new_type is not null "
               "group by company "
               "having count(distinct scmlog.id) > 1 "
               "order by count(distinct scmlog.id) desc "
               , (start_time, end_time))
newton_comslist = cursor.fetchall()

print 'newton_coms', newton_comslist
print 'len(newton_coms)', len(newton_comslist)

# 获取全部参与开发的公司列表
cursor.execute("SELECT company, count(distinct repository_id) as numP, count(distinct scmlog.id) as numC, "
               "count(distinct repositories.new_type) as numT "
               "FROM scmlog, commits_lines, repositories "
               "where message not like '    Merge %%' "
               "and company is not null "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "and repositories.new_type is not null "
               "group by company "
               "having count(distinct scmlog.id) > 1 "
               "order by count(distinct scmlog.id) desc ")
all_comslist = cursor.fetchall()
print 'all_comslist', all_comslist
print 'len(all_comslist)', len(all_comslist)


# 分离数据
def extra_date(coms):
    comlist = []
    numP = []
    numC = []
    numT= []
    for i in range(len(coms)):
        comlist.append(coms[i][0])
        numP.append(coms[i][1])
        numC.append(coms[i][2])
        numT.append(coms[i][3])
    return comlist, numP, numC, numT


# 绘制直方图
def plot_hist(data, title, xlabel, ylabel, bins):
    # plt.figure(figsize=(6, 4))
    hist, bins = np.histogram(data, bins=bins)
    width = np.diff(bins)
    center = (bins[:-1] + bins[1:]) / 2

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.bar(center, hist, align='center', width=width)
    ax.set_xticks(bins)
    #fig.savefig("/tmp/out.png") fix
    #plt.hist(data, bins, alpha=0.5)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    path = path2 + "/figure/dashboard/" + title + ".png"
    fig.savefig(path)
    plt.show()


all_coms, all_numP, all_numC, all_numT = extra_date(all_comslist)
new_coms, new_numP, new_numC, new_numT = extra_date(newton_comslist)

bins_commit = [0, 25, 50, 100, 200, 400]
plot_hist(all_numP, 'Hist of projects contributed by the companies', 'Projects',
          'Count', bins_commit)
bins_commit = [0, 5000, 10000, 25000, 53773]
plot_hist(all_numC, 'Hist of commits contributed by the companies', 'Commits', 'Count', bins_commit)

bins_commit = [0, 2, 4, 6, 8, 10, 12, 14]
plot_hist(all_numT, 'Hist of repository\'s type contributed by the companies', 'Manpower', 'Count', bins_commit)

# newton版本的直方图
bins_commit = [0, 25, 50, 100, 200, 300]
plot_hist(new_numP, 'Hist of projects contributed by the companies in the Newton version',
          'Projects', 'Count', bins_commit)
bins_commit = [0, 500, 1000, 3000, 7000]
plot_hist(new_numC, 'Hist of commits contributed by the companies in the Newton version',
          'Commits', 'Count', bins_commit)
bins_commit = [0, 2, 4, 6, 8, 10, 12, 14]
plot_hist(new_numT, 'Hist of repository\'s type contributed by the companies in the Newton version',
          'Manpower', 'Count', bins_commit)


'''
# 获取各个公司参与开发的项目数
def num_projects(coms, stime, etime, ):
    if stime is None:
        numP = []
        for i in range(len(coms)):
            cursor.execute("SELECT count(distinct repository_id) "
                           "FROM scmlog, commits_lines "
                           "where message not like '    Merge %%' "
                           "and company like %s "
                           "and scmlog.id = commits_lines.commit_id "
                           "and (commits_lines.added != 0 or commits_lines.removed != 0) ", coms[i][0])
            res = cursor.fetchall()[0]
            numP.append(res)
        print numP
        return numP
    else:
        numP = []
        for i in range(len(coms)):
            cursor.execute("SELECT count(distinct repository_id) "
                           "FROM scmlog, commits_lines "
                           "where date between %s and %s "
                           "and message not like '    Merge %%' "
                           "and company like %s "
                           "and scmlog.id = commits_lines.commit_id "
                           "and (commits_lines.added != 0 or commits_lines.removed != 0) ",
                           (stime, etime, coms[i][0]))
            res = cursor.fetchall()[0]
        numP.append(res)
        print numP
        return numP

newton_numP = num_projects(newton_comslist, start_time, end_time)
all_numP = num_projects(all_comslist, None, None)
'''

conn.commit()
cursor.close()
conn.close()

