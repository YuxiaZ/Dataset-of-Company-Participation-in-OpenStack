#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
from scipy import stats

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2
version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='utf8')
cursor = conn.cursor()


version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']
num_com = []
all_cmm = []
com_cmm_list = []
for i in range(14):
    start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
    end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
    print start_time, end_time
    cursor.execute("SELECT count(distinct company) "
                   "FROM scmlog, commits_lines, repositories "
                   "where company is not null "
                   "and message not like '    Merge %%' "
                   "and date between %s and %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null ", (start_time, end_time))
    res1 = cursor.fetchall()
    num_com.append(res1[0][0])
