#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='zhangyuxia23',
                       db='openstack_sourcecode', charset='utf8')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']

# 获取全部参与开发的公司列表
cursor.execute("SELECT company, count(distinct repository_id) as numP, count(distinct scmlog.id) as numC, "
               "count(distinct repositories.new_type) as numT "
               "FROM scmlog, commits_lines, repositories "
               "where message not like '    Merge %%' "
               "and company is not null "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "and repositories.new_type is not null "
               "group by company "
               "having count(distinct scmlog.id) > 14 "
               "order by count(distinct scmlog.id) desc ")
comslist = cursor.fetchall()
print 'comslist', comslist


# 分离数据
def extra_date(num1, re, ro, num2):
    if num1 > 0:
        re.append(num1)
        ro.append(num1/num2)
    return re, ro


coms_num_repo = []
coms_num_repo_type = []
coms_num_commit = []
coms_num_dvp = []

ratio_coms_num_repo = []
ratio_coms_num_repo_type = []
ratio_coms_num_commit = []
ratio_coms_num_dvp = []

for j in range(len(comslist)):
    print '********************************', j, '**********************************'
    print 'company', comslist[j][0]
    num_repo = []
    num_repo_type = []
    num_commit = []
    num_dvp = []

    ratio_num_repo = []
    ratio_num_repo_type = []
    ratio_num_commit = []
    ratio_num_dvp = []
    for i in range(14):
        start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
        end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
        print start_time, end_time
        cursor.execute("SELECT count(distinct repository_id), count(distinct repositories.new_type), "
                       "count(distinct scmlog.id), count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null "
                       "group by company ", (comslist[j][0], start_time, end_time))
        res = cursor.fetchall()
        print 'res', res
        if len(res) > 0:
            cursor.execute("SELECT count(distinct repository_id), count(distinct repositories.new_type), "
                           "count(distinct scmlog.id), count(distinct scmlog.author_id) "
                           "FROM scmlog, commits_lines, repositories "
                           "where message not like '    Merge %%' "
                           "and date between %s and %s "
                           "and scmlog.id = commits_lines.commit_id "
                           "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                           "and repository_id = repositories.id "
                           "and repositories.new_type is not null ", (start_time, end_time))
            sum = cursor.fetchall()

            num_repo, ratio_num_repo = extra_date(res[0][0], num_repo, ratio_num_repo, sum[0][0])
            num_repo_type, ratio_num_repo_type = extra_date(res[0][1], num_repo_type, ratio_num_repo_type, sum[0][1])
            num_commit, ratio_num_commit = extra_date(res[0][2], num_commit, ratio_num_commit, sum[0][2])
            num_dvp, ratio_num_dvp = extra_date(res[0][3], num_dvp, ratio_num_dvp, sum[0][3])

    coms_num_repo.append([mean(num_repo), median(num_repo)])
    coms_num_repo_type.append([mean(num_repo_type), median(num_repo_type)])
    coms_num_commit.append([mean(num_commit), median(num_commit)])
    coms_num_dvp.append([mean(num_dvp), median(num_dvp)])

    ratio_coms_num_repo.append([mean(ratio_num_repo), median(ratio_num_repo)])
    ratio_coms_num_repo_type.append([mean(ratio_num_repo_type), median(ratio_num_repo_type)])
    ratio_coms_num_commit.append([mean(ratio_num_commit), median(ratio_num_commit)])
    ratio_coms_num_dvp.append([mean(ratio_num_dvp), median(ratio_num_dvp)])


print 'coms_num_repo', coms_num_repo
print 'coms_num_repo_type', coms_num_repo_type
print 'coms_num_commit', coms_num_commit
print 'coms_num_dvp', coms_num_dvp

print 'ratio_coms_num_repo', ratio_coms_num_repo
print 'ratio_coms_num_repo_type', ratio_coms_num_repo_type
print 'ratio_coms_num_commit', ratio_coms_num_commit
print 'ratio_coms_num_dvp', ratio_coms_num_dvp


def write_data(fileName="", dataList=[]):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in dataList:
            data = [unicode(s).encode("utf-8") for s in data]
            csvWriter.writerow(data)
        csvFile.close

write_data(path2 + "/data/dashboard/comslist.csv", comslist)
write_data(path2 + "/data/dashboard/coms_num_repo.csv", coms_num_repo)
write_data(path2 + "/data/dashboard/coms_num_repo_type.csv", coms_num_repo_type)
write_data(path2 + "/data/dashboard/coms_num_commit.csv", coms_num_commit)
write_data(path2 + "/data/dashboard/coms_num_dvp.csv", coms_num_dvp)

write_data(path2 + "/data/dashboard/ratio_coms_num_repo.csv", ratio_coms_num_repo)
write_data(path2 + "/data/dashboard/ratio_coms_num_repo_type.csv", ratio_coms_num_repo_type)
write_data(path2 + "/data/dashboard/ratio_coms_num_commit.csv", ratio_coms_num_commit)
write_data(path2 + "/data/dashboard/ratio_coms_num_dvp.csv", ratio_coms_num_dvp)




# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            dataList.append(tmpList)
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList


# 变换数据格式
def change_formate(dataset):
    temp = []
    for i in range(len(dataset)):
        if len(dataset[i]) == 1:
            if "." in dataset[i][0]:
                value = float(dataset[i][0])
            else:
                value = int(dataset[i][0])
            print value
        else:
            value = []
            for j in range(len(dataset[i])):
                if dataset[i][j].isdigit():
                    if "." in dataset[i][j]:
                        value.append(float(dataset[i][j]))
                    else:
                        value.append(int(dataset[i][j]))
                else:
                    value.append(dataset[i][j])
        temp.append(value)
    return temp


comslist = readListCSV(path2 + "/data/dashboard/comslist.csv")
coms_num_repo = readListCSV(path2 + "/data/dashboard/coms_num_repo.csv")
coms_num_repo_type = readListCSV(path2 + "/data/dashboard/coms_num_repo_type.csv")
coms_num_commit = readListCSV(path2 + "/data/dashboard/coms_num_commit.csv")
coms_num_dvp = readListCSV(path2 + "/data/dashboard/coms_num_dvp.csv")
coms_num_dvp = change_formate(coms_num_dvp)

ratio_coms_num_repo = readListCSV(path2 + "/data/dashboard/ratio_coms_num_repo.csv")
ratio_coms_num_repo_type = readListCSV(path2 + "/data/dashboard/ratio_coms_num_repo_type.csv")
ratio_coms_num_commit = readListCSV(path2 + "/data/dashboard/ratio_coms_num_commit.csv")
ratio_coms_num_dvp = readListCSV(path2 + "/data/dashboard/ratio_coms_num_dvp.csv")
ratio_coms_num_dvp = change_formate(ratio_coms_num_dvp)

print 'comslist', comslist
print 'coms_num_repo', coms_num_repo
print 'coms_num_repo_type', coms_num_repo_type
print 'coms_num_commit', coms_num_commit
print 'coms_num_dvp', coms_num_dvp


print 'ratio_coms_num_repo', ratio_coms_num_repo
print 'ratio_coms_num_repo_type', ratio_coms_num_repo_type
print 'ratio_coms_num_commit', ratio_coms_num_commit
print 'ratio_coms_num_dvp', ratio_coms_num_dvp

dataset = []
for i in range(len(comslist)):
    if comslist[i][2] > 14:
        '''company, count(distinct repository_id), count(distinct scmlog.id), "
               "count(distinct repositories.new_type)'''
        dataset.append([comslist[i][0], comslist[i][3], comslist[i][1], comslist[i][2],
                        coms_num_repo[i][0], ratio_coms_num_repo[i][0],
                        coms_num_repo_type[i][0], ratio_coms_num_repo_type[i][0],
                        coms_num_commit[i][0], ratio_coms_num_commit[i][0],
                        coms_num_dvp[i][0], ratio_coms_num_dvp[i][0],
                        coms_num_repo[i][1], ratio_coms_num_repo[i][1],
                        coms_num_repo_type[i][1], ratio_coms_num_repo_type[i][1],
                        coms_num_commit[i][1], ratio_coms_num_commit[i][1],
                        coms_num_dvp[i][1], ratio_coms_num_dvp[i][1]])
        print "***************************"
        print 'company  all_project all_repoType all_commits ' \
              'avg_repo ratio avg_repoType ratio avg_commits ratio avg_dvp ratio' \
              'mid_repo ratio mid_repoType ratio mid_commits ratio mid_dvp ratio'
        print dataset[i]

write_data(path2 + "/data/dashboard/coms_contri_list2.csv", dataset)


# 绘制直方图
def plot_hist(data, title, xlabel, ylabel, bins):
    # plt.figure(figsize=(6, 4))
    hist, bins = np.histogram(data, bins=bins)
    width = np.diff(bins)
    center = (bins[:-1] + bins[1:]) / 2

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.bar(center, hist, align='center', width=width)
    ax.set_xticks(bins)
    #fig.savefig("/tmp/out.png") fix
    #plt.hist(data, bins, alpha=0.5)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    path = path2 + "/figure/dashboard/" + title + ".png"
    fig.savefig(path)
    plt.show()


conn.commit()
cursor.close()
conn.close()

