#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division

from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
# import pandas as pd
import math
import csv
import os

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='utf8')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']

# RQ1: 公司和志愿者在人力投入上的比值

com_manpower = []
idp_manpower = []
com_commit = []
idp_commit = []

num_com_manpower = []
num_com_commit = []

coms_manpower = []
coms_commits = []

shang_manpower = []
shang_commits = []
num_company = []

domination_manpower = []
domination_commits = []

version = range(1, 15)
print 'version: ', version

for i in range(14):  # 按照版本获取公司参与
    start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
    end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
    print start_time, end_time
    cursor.execute("SELECT count(distinct author_id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company is not null "
                   "and company not like 'independent' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0)",
                   (start_time, end_time))

    res = cursor.fetchall()
    com_manpower.append([res[0][0]])

    cursor.execute("SELECT count(distinct author_id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company like 'independent' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0)",
                   (start_time, end_time))
    res = cursor.fetchall()
    idp_manpower.append([res[0][0]])

    # print com_people, idp_people
    # num_manpower.append([com_people, idp_people])
    # 计算commit的比值
    cursor.execute("SELECT count(distinct scmlog.id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company is not null "
                   "and company not like 'independent' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0)",
                   (start_time, end_time))

    res = cursor.fetchall()
    com_commit.append([res[0][0]])

    cursor.execute("SELECT count(distinct scmlog.id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company like 'independent' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) ",
                   (start_time, end_time))
    res = cursor.fetchall()
    idp_commit.append([res[0][0]])

    # print com_commit, idp_commit
    # num_commit.append([com_commit, idp_commit])

    # 计算各个公司投入的人力以及贡献的代码
    cursor.execute("SELECT company, count(scmlog.id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company is not null "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "group by company "
                   "order by count(scmlog.id) desc"
                   , (start_time, end_time))

    each_com_commits = cursor.fetchall()
    for j in range(len(each_com_commits)):
        num_com_commit.append([i + 1, each_com_commits[j][0], each_com_commits[j][1]])

    cursor.execute("SELECT company, count(distinct author_id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company is not null "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "group by company "
                   "order by count(distinct author_id) desc "
                   , (start_time, end_time))

    each_com_manpower = cursor.fetchall()
    for h in range(len(each_com_manpower)):
        num_com_manpower.append([i + 1, each_com_manpower[h][0], each_com_manpower[h][1]])

    # 计算熵值
    # 人力投入熵
    cursor.execute("SELECT count(distinct author_id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company is not null "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) ",
                   (start_time, end_time))
    all_people = cursor.fetchone()[0]
    print all_people

    shang = 0
    domination = each_com_manpower[0][1] / all_people
    domination_manpower.append([domination])
    for j in range(len(each_com_manpower)):
        p = each_com_manpower[j][1] / all_people
        print p
        shang += -p * math.log(p, 2)
        print shang
    print shang
    shang_manpower.append([shang])

    # 代码熵
    cursor.execute("SELECT count(distinct scmlog.id) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and company is not null "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   , (start_time, end_time))
    all_commits = cursor.fetchone()[0]

    print all_commits

    shang = 0
    domination = each_com_commits[0][1] / all_commits
    domination_commits.append([domination])
    for j in range(len(each_com_commits)):
        p = each_com_commits[j][1] / all_commits
        print p
        shang += -p * math.log(p, 2)
        print shang
    print shang
    shang_commits.append([shang])

    cursor.execute("SELECT count(distinct company) "
                   "FROM scmlog, commits_lines "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company is not null "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) ",
                   (start_time, end_time))
    num_com = cursor.fetchone()[0]
    print 'num_com', num_com
    num_company.append([num_com])

# 计算总体上各个公司贡献的commit
cursor.execute("SELECT company, count(scmlog.id) "
               "FROM scmlog, commits_lines "
               "where message not like '    Merge %%' "
               "and company is not null "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "group by company "
               "order by count(scmlog.id) desc")
coms_commits = cursor.fetchall()
# 计算总体上各个公司贡献的人力
cursor.execute("SELECT company, count(distinct author_id) "
               "FROM scmlog, commits_lines "
               "where message not like '    Merge %%' "
               "and company is not null "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "group by company "
               "order by count(distinct author_id) desc")
coms_manpower = cursor.fetchall()

print 'com_manpower: ', com_manpower
print 'idp_manpower: ', idp_manpower
print 'com_commit: ', com_commit
print 'idp_commit: ', idp_commit
print 'num_com_manpower: ', num_com_manpower
print 'num_com_commit: ', num_com_commit
print 'coms_commits: ', coms_commits
print 'coms_manpower: ', coms_manpower
print 'shang_manpower: ', shang_manpower
print 'shang_commits: ', shang_commits
print 'domination_manpower: ', domination_manpower
print 'domination_commits: ', domination_commits
print 'num_company: ', num_company

com_manpower = np.array(com_manpower)


def write_data(fileName="", dataList=[]):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in dataList:
            data = [unicode(s).encode("utf-8") for s in data]
            csvWriter.writerow(data)
        csvFile.close


write_data(path2 + "/data/com_manpower.csv", com_manpower)
write_data(path2 + "/data/idp_manpower.csv", idp_manpower)
write_data(path2 + "/data/com_commit.csv", com_commit)
write_data(path2 + "/data/idp_commit.csv", idp_commit)
write_data(path2 + "/data/num_com_manpower.csv", num_com_manpower)
write_data(path2 + "/data/num_com_commit.csv", num_com_commit)
write_data(path2 + "/data/coms_commits.csv", coms_commits)
write_data(path2 + "/data/coms_manpower.csv", coms_manpower)
write_data(path2 + "/data/shang_manpower.csv", shang_manpower)
write_data(path2 + "/data/shang_commits.csv", shang_commits)
write_data(path2 + "/data/domination_manpower.csv", domination_manpower)
write_data(path2 + "/data/domination_commits.csv", domination_commits)
write_data(path2 + "/data/num_company.csv", num_company)
'''
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/com_manpower.csv', com_manpower, delimiter=',')
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/idp_manpower.csv', idp_manpower, delimiter=',')
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/com_commit.csv', com_commit, delimiter=',')
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/idp_commit.csv', idp_commit, delimiter=',')
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/num_com_manpower.csv', num_com_manpower,
           3, newline='\n')


np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/num_com_commit.csv', num_com_commit, delimiter=',',
           #fmt=['%d', '%s', '%d'])
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/coms_commits.csv', coms_commits, delimiter=',',
           fmt=['%s', '%d'])
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/coms_manpower.csv', coms_manpower, delimiter=',',
           fmt=['%s', '%d'])
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/shang_manpower.csv', shang_manpower, delimiter=',',
           fmt=['%f'])
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/shang_commits.csv', shang_commits, delimiter=',',
           fmt=['%f'])
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/domination_manpower.csv', domination_manpower, delimiter=',',
           fmt=['%f'])
np.savetxt('C:/Users/a/Desktop/untitled/FSE/data/domination_commits.csv', domination_commits, delimiter=',',
           fmt=['%f'])



com_commit1 = np.array(com_commit)
com_manpower1 = np.array(com_manpower)
idp_commit1 = np.array(idp_commit)
idp_manpower1 = np.array(idp_manpower)

com_per_commit = com_commit1/com_manpower1
idp_per_commit = idp_commit1/idp_manpower1
print 'com_per_commit: ', com_per_commit
print 'idp_per_commit: ', idp_per_commit
print 'mean(com_per_commit)', mean(com_per_commit)
print 'median(com_per_commit)', median(com_per_commit)
print 'mean(idp_per_commit)', mean(idp_per_commit)
print 'median(idp_per_commit)', median(idp_per_commit)
print 'mean(idp_manpower)', mean(idp_manpower)
print 'median(idp_manpower)', median(idp_manpower)
print 'mean(com_manpower)', mean(com_manpower)
print 'median(com_manpower)', median(com_manpower)

def percent(com, idp):
    # mean = 0
    # medium = 0
    percents = []
    for i in range(len(com)):
        percents.append(com[i] / (com[i] + idp[i]))
    print 'percents: ', percents
    # print mean(percents), median(percents)
    return mean(percents), median(percents)


mean_commits, medium_commits = percent(com_commit, idp_commit)
mean_manpower, medium_manpower = percent(com_manpower, idp_manpower)

print 'mean_commits, medium_commits', mean_commits, medium_commits
print 'mean_manpower, medium_manpower', mean_manpower, medium_manpower


# 绘制熵值和主导力度的曲线图
def plot_scatter(X, Y1, Y2, title, label1, label2):
    plt.figure(figsize=(8, 6))
    plt.plot(X, Y1, color="green", label=label1, linewidth=2)
    plt.plot(X, Y2, color="red", label=label2, linewidth=2)
    plt.legend()  # 绘制图例
    plt.savefig(title)
    plt.show()

plot_scatter(version, shang_manpower, shang_commits, 'Curve of entropy in manpower and commits',
             'shang_manpower', 'shang_commits')

plot_scatter(version, domination_manpower, domination_commits, 'Curve of domination in manpower and commits',
             'domination_manpower', 'domination_commits')


fig, ax = plt.subplots()
index = np.arange(14)
bar_width = 0.35
opacity = 0.4
com = plt.bar(index, com_manpower, bar_width, alpha=opacity, color='b', label='Company')
idp = plt.bar(index + bar_width, idp_manpower, bar_width, alpha=opacity, color='r', label='Volunteer')
plt.xlabel('Version')
plt.ylabel('Number of developers')
plt.title('The number of developers from companies and volunteers in OpenStack')
plt.xticks(index + bar_width, ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14'))
plt.ylim(0, 2500)
plt.legend()
plt.tight_layout()
plt.savefig('The number of developers from companies and volunteers in OpenStack')
plt.show()

# fig, ax = plt.subplots()
index = np.arange(14)
bar_width = 0.35
opacity = 0.4
com = plt.bar(index, com_commit, bar_width, alpha=opacity, color='b', label='Company')
idp = plt.bar(index + bar_width, idp_commit, bar_width, alpha=opacity, color='r', label='Volunteer')
plt.xlabel('Version')
plt.ylabel('Number of commits')
plt.title('The number of commits from companies and volunteers in OpenStack')
plt.xticks(index + bar_width, ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14'))
plt.ylim(0, 42200)
plt.legend()
plt.tight_layout()
plt.savefig('The number of commits from companies and volunteers in OpenStack')
plt.show()


def pie(coms, title):
    labels = []
    quants = []
    others = 0
    num_other_com = 0
    for i in range(len(coms)):
        if i < 9:
            labels.append(coms[i][0])
            quants.append(coms[i][1])
        else:
            others = others + coms[i][1]
            num_other_com = num_other_com + 1
    quants.append(others)
    labels.append(('others (#companies: ' + str(num_other_com) + ')'))

    print 'quants: ', quants
    print 'labels: ', labels

    # make a square figure
    plt.figure(1, figsize=(6, 6))
    plt.pie(quants, labels=labels)
    plt.title(title)
    plt.savefig(title)
    plt.show()


pie(coms_commits, 'The commits contributed by companies to OpenStack')
pie(coms_manpower, 'The manpower contributed by companies to OpenStack')


################################################
# 拟合OpenStack中公司人数随时间的增长模型
X = np.array(version)
Y = np.array(com_manpower)

d = {'X': X, 'Y': Y}
df = pd.DataFrame(data=d)

df['X2'] = df.X ** 2
model = smf.ols(formula='Y ~ X + X2', data=df)
results = model.fit()
print (results.summary())

#   绘图
c = results.params['Intercept']
b = results.params['X']
a = results.params['X2']

plt.figure(figsize=(8, 6))
plt.scatter(X, Y, color="green", label="sample data", linewidth=2)
#   画拟合直线
x = np.linspace(0, 12, 100)  ##在0-15直接画100个连续点
y = a * x * x + b * x + c  ##函数式
plt.plot(x, y, color="red", label="solution line", linewidth=2)
plt.legend()  # 绘制图例
plt.savefig('The growth model of companies\' developers in OpenStack')
plt.show()

################################################
# 拟合OpenStack中志愿者人数随时间的增长模型
version = range(1, 15)
print 'version: ', version

X = np.array(version)
Y = np.array(idp_manpower)

d = {'X': X, 'Y': Y}
df = pd.DataFrame(data=d)
model = smf.ols(formula='Y ~ X', data=df)
results = model.fit()
print (results.summary())

#   绘图
c = results.params['Intercept']
b = results.params['X']

plt.figure(figsize=(8, 6))
plt.scatter(X, Y, color="green", label="sample data", linewidth=2)

#   画拟合直线
x = np.linspace(0, 12, 100)  ##在0-15直接画100个连续点
y = b * x + c  ##函数式
plt.plot(x, y, color="red", label="solution line", linewidth=2)
plt.legend()  # 绘制图例
plt.savefig('The growth model of volunteers in OpenStack')
plt.show()

################################################
# 拟合OpenStack中公司贡献的代码随时间的增长模型
version = range(1, 15)
print 'version: ', version

X = np.array(version)
Y = np.array(com_commit)

d = {'X': X, 'Y': Y}
df = pd.DataFrame(data=d)

model = smf.ols(formula='Y ~ X', data=df)
results = model.fit()
print (results.summary())

df['X2'] = df.X ** 2
model = smf.ols(formula='Y ~ X + X2', data=df)
results = model.fit()
print (results.summary())

#   绘图
c = results.params['Intercept']
b = results.params['X']
a = results.params['X2']

plt.figure(figsize=(8, 6))
plt.scatter(X, Y, color="green", label="sample data", linewidth=2)

#   画拟合直线
x = np.linspace(0, 12, 100)  ##在0-15直接画100个连续点
y = a * x * x + b * x + c  ##函数式
plt.plot(x, y, color="red", label="solution line", linewidth=2)
plt.legend()  # 绘制图例
plt.savefig('The growth model of companies\' commits in OpenStack')
plt.show()

################################################
# 拟合OpenStack中志愿者贡献的代码随时间的增长模型
version = range(1, 15)
print 'version: ', version

X = np.array(version)
Y = np.array(idp_commit)

d = {'X': X, 'Y': Y}
df = pd.DataFrame(data=d)
model = smf.ols(formula='Y ~ X', data=df)
results = model.fit()
print (results.summary())

#   绘图
c = results.params['Intercept']
b = results.params['X']

plt.figure(figsize=(8, 6))
plt.scatter(X, Y, color="green", label="sample data", linewidth=2)

#   画拟合直线
x = np.linspace(0, 12, 100)  ## 在0-15直接画100个连续点
y = b * x + c  ## 函数式
plt.plot(x, y, color="red", label="solution line", linewidth=2)
plt.legend()  # 绘制图例
plt.savefig('The growth model of volunteers\' commits in OpenStack')
plt.show()

'''
conn.commit()
cursor.close()
conn.close()
