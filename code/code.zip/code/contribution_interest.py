#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2
version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='utf8')
cursor = conn.cursor()


version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']


def write_data(fileName="", dataList=[]):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in dataList:
            data = [unicode(s).encode("utf-8") for s in data]
            csvWriter.writerow(data)
        csvFile.close

# write_data(path2 + "/data/dashboard/comslist.csv", comslist)


# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            dataList.append(tmpList)
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList


def extra_date(num1, num2, re):
    if num1 > 0:
        re.append(num1/num2)
    return re


cursor.execute("SELECT * FROM com_model ")
coms_list = cursor.fetchall()
print 'coms_list', coms_list

interest_repoT = []