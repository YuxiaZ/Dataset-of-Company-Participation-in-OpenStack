#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
from scipy import stats
#import sklearn.liner_model
from sklearn.linear_model import LinearRegression
import seaborn as sns


reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

x_devp = np.loadtxt(path2+'/data/dyhg/x_devp_ratio.csv', delimiter=',')
x_cmm = np.loadtxt(path2+'/data/dyhg/x_cmm_ratio.csv', delimiter=',')
y_devp = np.loadtxt(path2+'/data/dyhg/y_devp_ratio.csv', delimiter=',')
y_cmm = np.loadtxt(path2+'/data/dyhg/y_cmm_ratio.csv', delimiter=',')

shang_cmm = np.loadtxt(path2+'/data/dyhg/shang_cmm.csv', delimiter=',')
shang_devp = np.loadtxt(path2+'/data/dyhg/shang_devp.csv', delimiter=',')

cmm = pd.read_csv(path2+'/data/dyhg/cmm1.csv')

print '熵值和志愿者贡献的commit之间的相关性'
corr, p_val = stats.spearmanr(shang_cmm, y_cmm)
print 'corr', corr
print 'p_val', p_val

print '熵值和志愿者人数之间的相关性'
corr, p_val = stats.spearmanr(shang_devp, y_devp)
print 'corr', corr
print 'p_val', p_val

print '熵值devp和志愿者贡献的commit之间的相关性'
corr, p_val = stats.spearmanr(shang_devp, y_cmm)
print 'corr', corr
print 'p_val', p_val

print '熵值cmm和志愿者人数之间的相关性'
corr, p_val = stats.spearmanr(shang_cmm, y_devp)
print 'corr', corr
print 'p_val', p_val

'''
def train_test_split(ylabel, random_state=1):
    import random
    index = random.sample(range(len(ylabel)), 5*random_state)
    list_train = []
    list_test = []
    i=0
    for s in range(len(ylabel)):
        if i in index:
            list_test.append(i)
        else:
            list_train.append(i)
        i += 1
    return list_train, list_test

# display the first 5 rows
print 'x_devp_ratio', x_devp
print 'y_devp_ratio', y_devp
print 'x_cmm_ratio', x_cmm
print 'y_cmm_ratio', y_cmm
print 'cmm', cmm

print cmm.head()
print cmm.tail()
print cmm.shape
# f1	f2	f3	s2	s3	u2	u3	p2	p3	d2	d3	t3

sns.pairplot(cmm, x_vars=['f1', 'f2', 'f3'], y_vars='idp_cmm', size=7, aspect=0.8, kind='reg')
#plt.show()

sns.pairplot(cmm, x_vars=['s2', 's3', 'u2', 'u3'], y_vars='idp_cmm', size=7, aspect=0.8, kind='reg')
#plt.show()

sns.pairplot(cmm, x_vars=['p2', 'p3', 'd2', 'd3', 't3'], y_vars='idp_cmm', size=7, aspect=0.8, kind='reg')
#plt.show()


# create a python list of feature names
#feature_cols = ['f1', 'f2', 'f3', 's2', 's3', 'u2', 'u3', 'p2', 'p3', 'd2', 'd3', 't3']
feature_cols = ['t3']
# use the list to select a subset of the original DataFrame
X = cmm[feature_cols]
# equivalent command to do this in one line
#X = cmm[['f1', 'f2', 'f3', 's2', 's3', 'u2', 'u3', 'p2', 'p3', 'd2', 'd3', 't3']]
# print the first 5 rows
print X.head()
# check the type and shape of X
print type(X)
print X.shape

# select a Series from the DataFrame
y = cmm['idp_cmm']
# equivalent command that works if there are no spaces in the column name
y = cmm.idp_cmm
# print the first 5 values
print y.head()

list_train, list_test = train_test_split(y)  # random_state的默认值是1

X_train = X.ix[list_train]  # 这里使用来DataFrame的ix（）函数，可以将指定list中的索引的记录全部放在一起
X_test = X.ix[list_test]
y_train = y.ix[list_train]
y_test = y.ix[list_test]
#######################开始进行模型的训练########################################

linreg = LinearRegression()
model = linreg.fit(X_train, y_train)
print model
print linreg.intercept_
print linreg.coef_

print zip(feature_cols, linreg.coef_)

y_pred = linreg.predict(X_test)
print y_pred
print y_test
print type(y_pred)
print 'R-score:', linreg.score(X_test, y_test)

'''