#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
from scipy import stats

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='zhangyuxia23',
                       db='openstack_sourcecode', charset='utf8')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05',
                '2012-09-27', '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30',
                '2015-10-16', '2016-04-07', '2016-10-06', '2017-02-22']

start_time = datetime.date(datetime.strptime('2016-04-07', '%Y-%m-%d'))
end_time = datetime.date(datetime.strptime('2016-10-06', '%Y-%m-%d'))

x_devp = [[0] * 12 for row in range(15)]
y_devp = []
x_cmm = [[0] * 12 for row in range(15)]
y_cmm = []


# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            dataList.append(tmpList)
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList


# 获取repo类型的名称
repoT_name = ['compute', 'storage',
              'networking', 'data analytics', 'security',
              'management tools', 'deployment tools', 'application services', 'monitoring',
              'develop infrastructure', 'document', 'community build', 'globalization',
              'architecture optimization', 'other']
print 'repoT_name', repoT_name

# 获取各个repo包含子项目的个数
cursor.execute("SELECT count(distinct repository_id) "
               "FROM scmlog, commits_lines, repositories "
               "where company is not null "
               "and date between %s and %s "
               "and message not like '    Merge %%' "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "group by repositories.new_type "
               "order by new_type", (start_time, end_time))
Type_numRepo = cursor.fetchall()
print 'Type_numRepo', Type_numRepo

# 获取志愿者的总体人数及其贡献比值
cursor.execute("SELECT count(distinct scmlog.author_id), count(distinct scmlog.id) "
               "FROM scmlog, commits_lines, repositories "
               "where company like 'independent' "
               "and date between %s and %s "
               "and message not like '    Merge %%' "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "and repositories.new_type is not null ", (start_time, end_time))
res1 = cursor.fetchall()
all_idp = res1[0][0]
all_idp_mm = res1[0][1]

# 获取各个repo类型上开发者的个数以及贡献
repoT_devp = []
repoT_devp_cmm = []
cursor.execute("SELECT repositories.new_type, repositories.id, count(distinct scmlog.author_id), "
               "count(distinct scmlog.id) "
               "FROM scmlog, commits_lines, repositories "
               "where company is not null "
               "and date between %s and %s "
               "and message not like '    Merge %%' "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "and repositories.new_type is not null "
               "group by repositories.new_type "
               "order by new_type", (start_time, end_time))
res2 = cursor.fetchall()
print 'res2', res2

for i in range(len(res2)):
    repoT_devp.append(res2[i][1])
    repoT_devp_cmm.append(res2[i][2])

# 获取各个repo类型上志愿者的参与人数
repoT_idp = []
repoT_idp_cmm = []
cursor.execute("SELECT repositories.new_type, count(distinct scmlog.author_id), count(distinct scmlog.id) "
               "FROM scmlog, commits_lines, repositories "
               "where company like 'independent' "
               "and date between %s and %s "
               "and message not like '    Merge %%' "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "and repositories.new_type is not null "
               "group by repositories.new_type "
               "order by new_type", (start_time, end_time))
res = cursor.fetchall()
print 'res', res
for i in range(len(res)):
    repoT_idp.append(res[i][1])
    repoT_idp_cmm.append(res[i][2])
    y_devp.append(res[i][1])
    y_cmm.append(res[i][2])
print 'repoT_idp', repoT_idp
print 'repoT_idp_cmm', repoT_idp_cmm

'''
# 获取各个repo类型上志愿者的人数以及贡献(相对值)
repoT_idp = []
repoT_idp_cmm = []
for i in range(15):
    cursor.execute("SELECT repository_id, repositories.new_type, "
                   "count(distinct scmlog.author_id), count(distinct scmlog.id) "
                   "FROM scmlog, commits_lines, repositories "
                   "where company like 'independent' "
                   "and date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type = %s "
                   "group by repository_id ", (start_time, end_time, i+1))
    res3 = cursor.fetchall()
    print 'res3', res3
    sum_idp = 0
    sum_idp_cmm = 0
    for j in range(len(res3)):
        sum_idp = sum_idp + res3[j][2]
        sum_idp_cmm = sum_idp_cmm + res3[j][3]
    repoT_idp.append(sum_idp)
    repoT_idp_cmm.append(sum_idp_cmm)

print 'repoT_idp', repoT_idp
print 'repoT_idp_cmm', repoT_idp_cmm
'''
# 获取各个类型repo上非志愿者且非归属于各个公司的开发者人数，和提交commit的个数
repoT_other_devp = []
repoT_other_cmm = []

cursor.execute("SELECT repositories.new_type, count(distinct scmlog.author_id), count(distinct scmlog.id) "
               "FROM scmlog, commits_lines, repositories "
               "where company not like 'independent' "
               "and company not in (select company from com_model)"
               "and date between %s and %s "
               "and message not like '    Merge %%' "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "group by repositories.new_type "
               "order by new_type", (start_time, end_time))
res = cursor.fetchall()
print 'res', res
for j in range(len(res)):
    repoT_other_devp.append(res[j][1])
    repoT_other_cmm.append(res[j][2])

print 'repoT_other_devp', repoT_other_devp
print 'repoT_other_cmm', repoT_other_cmm

# 获取各个类型repo不同model公司的组成情况
repoT_mcpos = []
for i in range(15):
    print "******************", i, "*********************"
    cursor.execute("SELECT com_model.idd, com_model.idd_name, "
                   "count(distinct scmlog.author_id), count(distinct scmlog.id) "
                   "FROM scmlog, commits_lines, repositories, com_model "
                   "where scmlog.company like com_model.company "
                   "and date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type = %s "
                   "group by com_model.idd "
                   "order by idd ", (start_time, end_time, i + 1))
    res = cursor.fetchall()
    repoT_mcpos.append(res)
    print 'test', res
    # 收集各类型上来自各模型的开发者和commit
    index = []
    for j in range(len(res)):
        index.append(res[j][0])
    print 'index', index
    for h in range(len(index)):
        x_devp[i][index[h] - 1] = res[h][2]
        x_cmm[i][index[h] - 1] = res[h][3]
    print 'x_devp', x_devp
    print 'x_cmm', x_cmm

print 'repoT_mcpos', repoT_mcpos


# 分析在总体上，各种model公司参与各种类型的repo 跟志愿者人数、贡献之间的关系


def plot_bar(y1, y2, label1, label2, xticks, title):
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    index = np.arange(15)
    bar_width = 0.3
    ax.bar(index, y1, width=0.3, color='y', label=label1)
    ax.bar(index + bar_width, y2, width=0.3, color='g', label=label2)
    ax.set_title(title)
    # plt.xticks(range(0, 15), xticks)
    ax.set_xticklabels(xticks, rotation=15, fontsize=10, ha='center')
    ax.set_xticks(index)
    plt.legend()
    # ax.get_legend_handles_labels()
    # ax.set_xticklabels(labels)
    path = path2 + "/figure/model_idp/" + title + ".png"
    fig.savefig(path)
    plt.show()


'''
# 志愿者及其commit在各个类型上的分布
test = [int(i/10) for i in repoT_idp_cmm]
print 'test', test
plot_bar(repoT_idp, test, '# volunteer', '# commit/10', repoT_name,
         'The distribution of volunteers and their commits in the types of repositories')
'''

# 志愿者及其commit在各个类型上的分布相对志愿者总体的比例
test1 = []
test2 = []
for i in range(15):
    test1.append(repoT_idp[i] / all_idp / Type_numRepo[i][0])
    test2.append(repoT_idp_cmm[i] / all_idp_mm / Type_numRepo[i][0])
#plot_bar(test1, test2, '% volunteer', '% commit', repoT_name,
         #'The percentage of volunteers and their commits in all volunteers')
'''
# 志愿者及其commit在各个类型上的分布相对项目类型总体的比例
test1 = []
test2 = []
for i in range(15):
    test1.append((repoT_idp[i]/repoT_devp[i])/Type_numRepo[i][0])
    test2.append((repoT_idp_cmm[i]/repoT_devp_cmm[i])/Type_numRepo[i][0])
plot_bar(test1, test2, '% volunteer', '% commit', repoT_name,
         'The percentage of volunteers and their commits in the types of repositories')
'''


def pie(value, label, title):
    fig, ax = plt.subplots()
    ax.pie(value, labels=label, autopct='%1.0f%%', startangle=170)
    ax.axis('equal')
    ax.set_title(title)
    path = path2 + "/figure/model_idp/" + title + ".png"
    plt.savefig(path)
    plt.show()


# pie(repoT_idp, repoT_name, 'The distribution of volunteers in the types of sub_projects')
# pie(repoT_idp_cmm, repoT_name, 'The distribution of volunteers\' commits in the types of sub_projects')

repoT_sum_devp = []
repoT_sum_cmm = []
repoT_ratio_idp = []
repoT_ratio_idp_cmm = []
for i in range(15):
    model_devp = []
    model_cmm = []
    model_name = []
    for j in range(len(repoT_mcpos[i])):
        model_devp.append(repoT_mcpos[i][j][2])
        model_cmm.append(repoT_mcpos[i][j][3])
        model_name.append(repoT_mcpos[i][j][1])
    model_devp.append(repoT_idp[i])
    model_name.append('volunteer')
    model_cmm.append(repoT_idp_cmm[i])
    model_devp.append(repoT_other_devp[i])
    model_name.append('other')
    model_cmm.append(repoT_other_cmm[i])
    repoT_sum_devp.append(sum(model_devp))
    repoT_sum_cmm.append(sum(model_cmm))
    repoT_ratio_idp.append(repoT_idp[i] / sum(model_devp))
    repoT_ratio_idp_cmm.append(repoT_idp_cmm[i] / sum(model_cmm))
'''
    pie(model_devp, model_name,
        "The distribution of developers from different models in the " + repoT_name[i] + " type")
    pie(model_cmm, model_name, "The distribution of commits from different models in the " + repoT_name[i] + " type")
'''


'''
plot_bar(repoT_ratio_idp, repoT_ratio_idp_cmm, '% volunteer', '% commit', repoT_name,
         'The ratio of volunteers and their commits in the types of repositories')
'''

y_devp_ratio = []
y_cmm_ratio = []
x_devp_ratio = [[0] * 12 for row in range(15)]
x_cmm_ratio = [[0] * 12 for row in range(15)]
for i in range(15):
    y_devp_ratio.append(y_devp[i] / all_idp / Type_numRepo[i][0])
    y_cmm_ratio.append(y_cmm[i] / all_idp_mm / Type_numRepo[i][0])
    for j in range(12):
        x_devp_ratio[i][j] = x_devp[i][j] / repoT_sum_devp[i] / Type_numRepo[i][0]
        x_cmm_ratio[i][j] = x_cmm[i][j] / repoT_sum_cmm[i] / Type_numRepo[i][0]

shang_devp = []
shang_cmm = []
for i in range(15):
    shang_d = 0
    shang_c = 0
    for j in range(12):
        p_devp = x_devp[i][j] / repoT_sum_devp[i]
        p_cmm = x_cmm[i][j] / repoT_sum_cmm[i]
        print p_devp, p_cmm
        if p_devp > 0 and p_cmm > 0:
            shang_d += -p_devp * math.log(p_devp, 2)
            shang_c += -p_cmm * math.log(p_cmm, 2)
    shang_devp.append(shang_d)
    shang_cmm.append(shang_c)
print 'shang_devp', shang_devp
print 'shang_cmm', shang_cmm
'''
    shang = 0
    domination = each_com_commits[0][1] / all_commits
    domination_commits.append([domination])
    for j in range(len(each_com_commits)):
        p = each_com_commits[j][1] / all_commits
        print p
        shang += -p * math.log(p, 2)
        print shang
    print shang
    shang_commits.append([shang])
'''

print 'x_devp', x_devp
print 'y_devp', y_devp
print 'x_cmm', x_cmm
print 'y_cmm', y_cmm

print 'x_devp_ratio', x_devp_ratio
print 'y_devp_ratio', y_devp_ratio
print 'x_cmm_ratio', x_cmm_ratio
print 'y_cmm_ratio', y_cmm_ratio

np.savetxt(path2 + "/data/dyhg/x_devp_ratio.csv", x_devp_ratio, delimiter=',', fmt='%1.3f')
np.savetxt(path2 + "/data/dyhg/y_devp_ratio.csv", y_devp_ratio, delimiter=',', fmt='%1.3f')
np.savetxt(path2 + "/data/dyhg/x_cmm_ratio.csv", x_cmm_ratio, delimiter=',', fmt='%1.3f')
np.savetxt(path2 + "/data/dyhg/y_cmm_ratio.csv", y_cmm_ratio, delimiter=',', fmt='%1.3f')

np.savetxt(path2 + "/data/dyhg/shang_devp.csv", shang_devp, delimiter=',', fmt='%1.3f')
np.savetxt(path2 + "/data/dyhg/shang_cmm.csv", shang_cmm, delimiter=',', fmt='%1.3f')

conn.commit()
cursor.close()
conn.close()
