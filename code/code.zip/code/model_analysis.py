#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
from scipy import stats

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='zhangyuxia23',
                       db='openstack_sourcecode', charset='utf8')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']


# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            dataList.append(tmpList)
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList
'''
m1p_repo = np.loadtxt(path2 + "/data/dashboard/model1_prefer_repo.csv", delimiter=",")
m2p_repo = np.loadtxt(path2 + "/data/dashboard/model2_prefer_repo.csv", delimiter=",")
m3p_repo = np.loadtxt(path2 + "/data/dashboard/model3_prefer_repo.csv", delimiter=",")
m4p_repo = np.loadtxt(path2 + "/data/dashboard/model4_prefer_repo.csv", delimiter=",")
m5p_repo = np.loadtxt(path2 + "/data/dashboard/model5_prefer_repo.csv", delimiter=",")

print 'm1p_repo', m1p_repo
print 'm2p_repo', m2p_repo
print 'm3p_repo', m3p_repo
print 'm4p_repo', m4p_repo
print 'm5p_repo', m5p_repo

print type(m1p_repo)
print max(m1p_repo)
print m1p_repo.argmax(axis=0)

exp_repo1 = []
exp_repo2 = []
exp_repo3 = []
exp_repo4 = []
exp_repo5 = []

for i in range(3):
    exp_repo1.append(m1p_repo.argmax(axis=0))
    m1p_repo[m1p_repo.argmax(axis=0)] = 0

    exp_repo2.append(m2p_repo.argmax(axis=0))
    m2p_repo[m2p_repo.argmax(axis=0)] = 0

    exp_repo3.append(m3p_repo.argmax(axis=0))
    m3p_repo[m3p_repo.argmax(axis=0)] = 0

    exp_repo4.append(m4p_repo.argmax(axis=0))
    m4p_repo[m4p_repo.argmax(axis=0)] = 0

    exp_repo5.append(m5p_repo.argmax(axis=0))
    m5p_repo[m5p_repo.argmax(axis=0)] = 0

print 'exp_repo1', exp_repo1
print 'exp_repo2', exp_repo2
print 'exp_repo3', exp_repo3
print 'exp_repo4', exp_repo4
print 'exp_repo5', exp_repo5
'''
sample = [226, 185, 287, 332]
coms_s = []
authors_s = []
dominant_s = []
dom_com_s = []
ind_cmt_s = []
ind_dvp_s = []
cmms_s = []
for j in range(4):
    dominant = []
    dom_com = []
    ind_cmt = []
    ind_dvp = []
    coms = []
    cmms = []
    authors = []

    for i in range(14):
        start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
        end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
        print start_time, end_time
        cursor.execute("SELECT company, count(distinct scmlog.id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where repository_id = %s "
                       "and company is not null "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null "
                       "group by company "
                       "order by count(distinct scmlog.id) desc ",
                       (sample[j], start_time, end_time))
        res1 = cursor.fetchall()
        if len(res1) == 0:
            continue
        cursor.execute("SELECT count(distinct scmlog.id), count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where repository_id = %s "
                       "and company like 'independent' "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null ",
                       (sample[j], start_time, end_time))
        res2 = cursor.fetchall()

        cursor.execute("SELECT count(distinct scmlog.id), count(distinct scmlog.author_id), "
                       "count(distinct company) "
                       "FROM scmlog, commits_lines, repositories "
                       "where repository_id = %s "
                       "and company is not null "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null ",
                       (sample[j], start_time, end_time))
        res3 = cursor.fetchall()

        cmms.append(res3[0][0])
        coms.append(res3[0][2] - 2)
        authors.append(res3[0][1])
        dominant.append(res1[0][1]/res3[0][0])
        dom_com.append(res1[0][0])
        ind_cmt.append(res2[0][0])
        ind_dvp.append(res2[0][1])

    dominant_s.append(dominant)
    dom_com_s.append(dom_com)
    ind_cmt_s.append(ind_cmt)
    ind_dvp_s.append(ind_dvp)
    coms_s.append(coms)
    cmms_s.append(cmms)
    authors_s.append(authors)

    print 'dominant', dominant
    print 'dom_com', dom_com
    print 'ind_cmt', ind_cmt
    print 'ind_dvp', ind_dvp
    print 'coms', coms
    print 'authors', authors
    print '*******************', sample[j]
    print '主导和志愿者贡献的commit之间的相关性'
    corr, p_val = stats.spearmanr(dominant[0:len(dominant)-1], ind_cmt[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

    corr, p_val = stats.pearsonr(dominant[0:len(dominant)-1], ind_cmt[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

    print '主导和志愿者之间的相关性'
    corr, p_val = stats.spearmanr(dominant[0:len(dominant)-1], ind_dvp[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

    corr, p_val = stats.pearsonr(dominant[0:len(dominant)-1], ind_dvp[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

    print '主导和公司参与之间的相关性'
    corr, p_val = stats.spearmanr(dominant[0:len(dominant)-1], coms[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

    corr, p_val = stats.pearsonr(dominant[0:len(dominant)-1], coms[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

    print '主导和贡献者之间的相关性'
    corr, p_val = stats.spearmanr(dominant[0:len(dominant)-1], authors[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

    corr, p_val = stats.pearsonr(dominant[0:len(dominant)-1], authors[1:len(dominant)])
    print 'corr', corr
    print 'p_val', p_val

print 'dominant_s', dominant_s
print 'dom_com_s', dom_com_s
print 'ind_cmt_s', ind_cmt_s
print 'ind_dvp_s', ind_dvp_s
print 'coms_s', coms_s
print 'authors_s', authors


def plot_scatter(X, Y1, Y2, title, coms):
    plt.figure(figsize=(8, 6))
    plt.plot(X, Y1, color="green", linewidth=2)
    plt.plot(X, Y2, color="red", linewidth=2)
    plt.xlabel(coms)
    plt.legend()  # 绘制图例
    #plt.savefig(title)
    plt.show()

for i in range(4):
    version = range(1, len(dominant_s[i])+1)
    plt.figure(figsize=(8, 6))
    plt.subplot(221)
    plt.plot(version, ind_cmt_s[i])
    plt.xlabel('version')
    plt.ylabel('commit')

    plt.subplot(222)
    plt.plot(version, ind_dvp_s[i])
    plt.xlabel('version')
    plt.ylabel('volunteer')

    plt.subplot(223)
    plt.plot(version, authors_s[i])
    plt.xlabel('version')
    plt.ylabel('contributor')

    plt.subplot(224)
    plt.plot(version, coms_s[i])
    plt.xlabel('version')
    plt.ylabel('companies')

    plt.show()

    plt.figure(figsize=(8, 6))
    plt.subplot(221)
    plt.scatter(dominant_s[i][0:len(dominant_s[i])-1], coms_s[i][1:len(dominant_s[i])],
                marker='o', color='r', s=15)
    plt.xlabel('dominant')
    plt.ylabel('number of companies')
    plt.title(i+1)

    plt.subplot(222)
    plt.scatter(dominant_s[i][0:len(dominant_s[i])-1], ind_cmt_s[i][1:len(dominant_s[i])],
                marker='o', color='y', s=15)
    plt.xlabel('dominant')
    plt.ylabel('commits of volunteer')

    plt.subplot(223)
    plt.scatter(dominant_s[i][0:len(dominant_s[i])-1], ind_dvp_s[i][1:len(dominant_s[i])],
                marker='o', color='y', s=15)
    plt.xlabel('dominant')
    plt.ylabel('volunteer')

    plt.subplot(224)
    plt.scatter(dominant_s[i][0:len(dominant_s[i])-1], authors_s[i][1:len(dominant_s[i])],
                marker='o', color='y', s=15)
    plt.xlabel('dominant')
    plt.ylabel('contributor')
    plt.show()

# 获取一些描述性统计量
mean_idp = []
median_idp = []

mean_idp_cmm = []
median_idp_cmm = []

mean_cbt = []
median_cbt = []

mean_com = []
median_com = []

mean_cmm = []
median_cmm = []

mean_domi = []
median_domi = []

for i in range(4):
    mean_idp.append(mean(ind_dvp_s[i]))
    median_idp.append(median(ind_dvp))

    mean_idp_cmm.append(mean(ind_cmt_s[i]))
    median_idp_cmm.append(median(ind_cmt_s[i]))

    mean_cbt.append(mean(authors_s[i]))
    median_cbt.append(median(authors_s[i]))

    mean_cmm.append(mean(cmms_s[i]))
    median_cmm.append(median(cmms_s[i]))

    mean_domi.append(mean(dominant_s[i]))
    median_domi.append(median(dominant_s[i]))

    mean_com.append(mean(coms_s[i]))
    median_com.append(median(coms_s[i]))


def plot_bar(y1, y2, title):
    index = np.arange(4)
    bar_width = 0.3
    plt.bar(index, y1, width=0.3, color='y')
    plt.bar(index + bar_width, y2, width=0.3, color='g')
    plt.title(title)
    plt.xticks(range(0, 4), ['Nova', 'Neutron', 'Swift', 'Gerrit'])
    plt.show()

plot_bar(mean_idp, median_idp, 'The mean/median number of volunteers in the four projects')
plot_bar(mean_idp_cmm, median_idp_cmm, 'The mean/median number of volunteers\'s commits '
                                       'in the four projects')
plot_bar(mean_cbt, median_cbt, 'The mean/median number of developers in the four projects')
plot_bar(mean_cmm, median_cmm, 'The mean/median number of commits in the four projects')
plot_bar(mean_com, median_com, 'The mean/median number of companies in the four projects')
plot_bar(mean_domi, median_domi, 'The mean/median number of dominant in the four projects')


conn.commit()
cursor.close()
conn.close()