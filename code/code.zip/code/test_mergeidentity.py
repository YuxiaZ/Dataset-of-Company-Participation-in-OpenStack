#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division

import os

import Levenshtein
import pymysql
from numpy import *

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2


def similar(strA, strB):
    simi = Levenshtein.distance(strA, strB)
    ratio = 1 - simi / max(len(strA), len(strB))
    if ratio >= 0.5:
        flag = 1
    else:
        flag = 0
    return simi, ratio, flag


conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='zhangyuxia23',
                       db='openstack_sourcecode', charset='utf8')
cursor = conn.cursor()

cursor.execute("select email, count(*) "
               "from people "
               "where email not like '' "
               "group by email "
               "order by count(*) desc")
emails = cursor.fetchall()
print emails

for i in range(len(emails)):  # 对每一个email进行处理
    print emails[i][0]
    cursor.execute("select id, name, email "
                   "from people "
                   "where email like '%s' " % emails[i][0])
    identities = cursor.fetchall()
    print identities

    strB = (''.join(e for e in emails[i][0].split("@")[0] if e.isalpha())).lower()
    print 'email_domain:', strB
    if emails[i][1] == 1:  # 不存在一人有多个账号现象
        break
    else:  # 邮件名为一串数字或者字符之类的无语义信息
        if len(strB) == 0:
            continue
        else:
            simi = []
            ratio = []
            flag = []
            for j in range(len(identities)):  # 判断同邮件的多用户名和邮箱名的相似度
                strA = (''.join(e for e in identities[j][1] if e.isalpha())).lower()
                print 'name:', strA
                print 'email_domain:', strB
                if len(strA) == 0:
                    simi.append(0)
                    ratio.append(0)
                    flag.append(0)
                    continue
                else:
                    simi.append(similar(strA, strB)[0])
                    ratio.append(similar(strA, strB)[1])
                    flag.append(similar(strA, strB)[2])
                    print 'simi', simi
                    print 'ratio', ratio
                    print 'flag', flag

            if flag.count(1) > 1:  # 对确实需要合并的账号进行合并处理
                index = ratio.index(max(ratio))
                name = identities[index][1]
                for k in range(len(identities)):
                    if flag[k] == 1:
                        id = identities[k][0]
                        break
                print 'id:', id
                print 'name', name
                cursor.execute('update people '  # 更新保留用户的名字为和邮箱相似度最高的名字
                               'set name = %s '
                               'where id = %s ',
                               (name, id))
                id_set = {'id': id, 'ids': str(id), 'name': name}
                for h in range(len(identities)):
                    if flag[h] == 1 and identities[h][0] != id:
                        print "**********************change*********************"
                        print 'identities[h][0]', identities[h][0]
                        cursor.execute('update scmlog '  # 合并scmlog表中的author_id
                                       'set author_id = %s, company = 0 '
                                       'where author_id = %s ',
                                       (id, identities[h][0]))

                        id_set['ids'] = id_set['ids'] + ' ' + str(identities[h][0])
                        id_set['name'] = id_set['name'] + ' # ' + (identities[h][1])
                        print 'id_set[id]', id_set['id']
                        print 'id_set[ids]', id_set['ids']
                        print 'id_set[name]', id_set['name']

                        cursor.execute('delete from people '  # 合并scmlog表中的author_id
                                       'where id = %s ',
                                       (identities[h][0]))
                print 'id_set', id_set
                cursor.execute('INSERT INTO IDset values(%s,%s,%s)',
                               (int(id_set['id']), id_set['ids'], id_set['name']))



conn.commit()
cursor.close()
conn.close()
