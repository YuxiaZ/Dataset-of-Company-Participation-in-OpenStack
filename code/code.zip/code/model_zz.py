#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
from sklearn.linear_model import LinearRegression
import seaborn as sns

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2
version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='utf8')
cursor = conn.cursor()


version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']
# 数据集获取

cursor.execute("SELECT * FROM com_model ")
coms_list = cursor.fetchall()
print 'coms_list', coms_list

coms = []
coms_m6 = []
coms_m12 = []
for i in range(len(coms_list)):
    coms.append(coms_list[i][0])
    coms_m6.append(coms_list[i][2])
    coms_m12.append(coms_list[i][3])
print 'coms', coms
print 'coms_m6', coms_m6
print 'coms_m12', coms_m12

# print coms.index('Mirantis')

data_set = []
for i in range(14):
    start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
    end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
    version = i+1
    # 获取当前版本repo的基本信息（id, type, ）
    cursor.execute("SELECT distinct repository_id, repositories.new_type, "
                   "count(distinct scmlog.id), count(distinct scmlog.author_id), "
                   "count(distinct company), project_type.key "
                   "FROM scmlog, commits_lines, repositories, project_type "
                   "where company is not null "
                   "and message not like '    Merge %%' "
                   "and date between %s and %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type !=15 "
                   "and repositories.new_type = project_type.id "
                   "group by repository_id "
                   "order by count(distinct scmlog.id) desc ", (start_time, end_time))
    res1 = cursor.fetchall()
    print 'repo_list', res1

    for j in range(len(res1)):  # 对当前版本的每一个repo进行处理
        # 获取该子项目的志愿者数和其提交的commit
        cursor.execute("SELECT count(distinct scmlog.id),  count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where repository_id = %s "
                       "and company like 'independent' "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type !=15 ", (res1[j][0], start_time, end_time))
        res2 = cursor.fetchall()
        print 'volunteers', res2
        total_dvpr = res1[j][3]
        total_cmm = res1[j][2]
        vltr = res2[0][1]  # 志愿者人数
        vltr_cmm = res2[0][0]   # 志愿者cmm
        type = res1[j][1]  # repo所属类型
        key = res1[j][5]  # type按照重要级排序 倒序
        repo_id = res1[j][0]
        rank = j+1  # 该项目的规模
        rank_r = (j+1)/len(res1)

        # 获取参与该repo的公司贡献列表
        cursor.execute("SELECT company, count(distinct scmlog.id),  count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where repository_id = %s "               
                       "and company is not null "
                       "and company not like 'independent' "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type !=15 "
                       "group by company ", (res1[j][0], start_time, end_time))
        res3 = cursor.fetchall()
        print 'coms_list', res3
        '''
        m6_devp = [0]*7
        m6_cmm = [0]*7
        # 计算墒值（6模型）*******************
        # 计算各个模型贡献值（devp, cmm）
        for k in range(len(res3)):
            if coms.count(res3[k][0]) > 0:
                print 'coms.index(res3[k][0])', coms.index(res3[k][0])
                print 'coms_m6[coms.index(res3[k][0])]', coms_m6[coms.index(res3[k][0])]
                m6_cmm[coms_m6[coms.index(res3[k][0])]-1] += res3[k][1]
                m6_devp[coms_m6[coms.index(res3[k][0])]-1] += res3[k][2]
            else:
                m6_cmm[6] += res3[k][1]
                m6_devp[6] += res3[k][2]
        print 'm6_devp', m6_devp
        print 'm6_cmm', m6_cmm
        # 计算墒值
        ep_devp6 = 0
        ep_cmm6 = 0
        ep_devp7 = 0
        ep_cmm7 = 0
        ep_devp8 = 0
        ep_cmm8 = 0
        for m in range(6):
            p = m6_devp[m] / res1[j][3]
            print p
            if p > 0:
                ep_devp6 += -p * math.log(p, 2)

            p = m6_cmm[m] / res1[j][2]
            print p
            if p > 0:
                ep_cmm6 += -p * math.log(p, 2)
        ep_devp7 = ep_devp6
        ep_cmm7 = ep_cmm6
        if vltr > 0:
            p1 = vltr/total_dvpr
            p2 = vltr_cmm/total_cmm
            ep_devp7 += -p1 * math.log(p1, 2)
            ep_cmm7 += -p2 * math.log(p2, 2)
        ep_devp8 = ep_devp7
        ep_cmm8 = ep_cmm7
        if m6_devp[6] > 0:
            p1 = m6_devp[6] / total_dvpr
            p2 = m6_cmm[6] / total_cmm
            print 'p', p1
            ep_devp8 += -p1 * math.log(p1, 2)
            ep_cmm8 += -p2 * math.log(p2, 2)
        print 'ep_devp6', ep_devp6
        print 'ep_cmm6', ep_cmm6
        print 'ep_devp7', ep_devp7
        print 'ep_cmm7', ep_cmm7
        print 'ep_devp8', ep_devp8
        print 'ep_cmm8', ep_cmm8
        print '#############'
        if vltr == 0 or ep_cmm6 == 0:
            continue
        else:
            data_set.append([repo_id, total_dvpr, total_cmm, vltr, vltr_cmm, type,
                             ep_devp6, ep_cmm6, ep_devp7, ep_cmm7, ep_devp8, ep_cmm8, version])
        '''
        m12_devp = [0]*13
        m12_cmm = [0]*13
        # 计算墒值（12模型）*******************
        # 计算各个模型贡献值（devp, cmm）
        for k in range(len(res3)):
            if coms.count(res3[k][0]) > 0:
                index = coms.index(res3[k][0])
                print 'index', index
                m12_cmm[coms_m12[index]-1] += res3[k][1]
                m12_devp[coms_m12[index]-1] += res3[k][2]
            else:
                m12_cmm[12] += res3[k][1]
                m12_devp[12] += res3[k][2]
        print 'm12_devp', m12_devp
        print 'm12_cmm', m12_cmm
        # 计算墒值
        ep_devp12 = 0
        ep_cmm12 = 0
        ep_devp13 = 0
        ep_cmm13 = 0
        ep_devp14 = 0
        ep_cmm14 = 0
        for m in range(12):
            p = m12_devp[m] / res1[j][3]
            print p
            if p > 0:
                ep_devp12 += -p * math.log(p, 2)

            p = m12_cmm[m] / res1[j][2]
            print p
            if p > 0:
                ep_cmm12 += -p * math.log(p, 2)
        ep_devp13 = ep_devp12
        ep_cmm13 = ep_cmm12
        if vltr > 0:
            p1 = vltr/total_dvpr
            p2 = vltr_cmm/total_cmm
            ep_devp13 += -p1 * math.log(p1, 2)
            ep_cmm13 += -p2 * math.log(p2, 2)
        ep_devp14 = ep_devp13
        ep_cmm14 = ep_cmm13
        if m12_devp[12] > 0:
            p1 = m12_devp[12] / total_dvpr
            p2 = m12_cmm[12] / total_cmm
            print 'p', p1
            ep_devp14 += -p1 * math.log(p1, 2)
            ep_cmm14 += -p2 * math.log(p2, 2)
        print 'ep_devp12', ep_devp12
        print 'ep_cmm12', ep_cmm12
        print 'ep_devp13', ep_devp13
        print 'ep_cmm13', ep_cmm13
        print 'ep_devp14', ep_devp14
        print 'ep_cmm14', ep_cmm14
        print '#############'
        if vltr == 0 or ep_cmm12 == 0:
            continue
        else:
            data_set.append([repo_id, total_dvpr, total_cmm, vltr, vltr_cmm, type,
                             ep_devp12, ep_cmm12, ep_devp13, ep_cmm13, ep_devp14, ep_cmm14,
                             version, rank, rank_r, key])
print 'data_set', data_set
np.savetxt(path2 + "/data/dashboard/model_zz33.csv", data_set, fmt="%f", delimiter=",")
'''
data_set = np.loadtxt(path2 + "/data/dashboard/model_zz.csv", delimiter=",")
ratio_vltr = np.loadtxt(path2 + "/data/dashboard/model_zz.csv", usecols=(0,), delimiter=",")
ratio_vltr_cmm = np.loadtxt(path2 + "/data/dashboard/model_zz.csv", usecols=(1,), delimiter=",")
repo_type = np.loadtxt(path2 + "/data/dashboard/model_zz.csv", usecols=(2,), delimiter=",")
ep_devp = np.loadtxt(path2 + "/data/dashboard/model_zz.csv", usecols=(3,), delimiter=",")
ep_cmm = np.loadtxt(path2 + "/data/dashboard/model_zz.csv", usecols=(4,), delimiter=",")
version = np.loadtxt(path2 + "/data/dashboard/model_zz.csv", usecols=(5,), delimiter=",")
print ratio_vltr
print ratio_vltr_cmm
print repo_type
print ep_devp
print ep_cmm
print version

linreg = LinearRegression()
model = linreg.fit(X_train, y_train)
print model
print linreg.intercept_
print linreg.coef_
'''

conn.commit()
cursor.close()
conn.close()