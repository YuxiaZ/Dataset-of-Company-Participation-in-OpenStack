#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
import smtplib
from email.mime.text import MIMEText
import re

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='latin1')
cursor = conn.cursor()


def sendmail(content, receivers, succ):
    # 设置服务器所需信息
    # 163邮箱服务器地址
    mail_host = 'smtp.gmail.com'
    # 163用户名
    mail_user = 'zhangyuxia23@gmail.com'
    # 密码(部分邮箱为授权码)
    mail_pass = '2011118066zyx'
    # 邮件发送方邮箱地址
    sender = 'zhangyuxia23@gmail.com'
    # 邮件接受方邮箱地址，注意需要[]包裹，这意味着你可以写多个邮件地址群发
    receivers = receivers

    # 设置email信息
    # 邮件内容设置

    message = MIMEText(content, 'plain', 'utf8')
    # 邮件主题
    message['Subject'] = 'A Simple Validation of Companies\' Contributions to OpenStack'
    # 发送方信息
    message['From'] = sender
    # 接受方信息
    # message['To'] = receivers[0]
    message['To'] = ';'.join(receivers)

    # 登录并发送邮件
    try:
        smtpObj = smtplib.SMTP()
        #smtpObj = smtplib.SMTP_SSL('smtp.163.com')
        # 连接到服务器
        smtpObj.connect(mail_host, 25)
        smtpObj.set_debuglevel(1)
        # 登录到服务器
        smtpObj.ehlo()
        smtpObj.starttls()
        smtpObj.login(mail_user, mail_pass)
        # 发送
        smtpObj.sendmail(
            sender, receivers, message.as_string())
        # 退出
        smtpObj.quit()
        print "#########################"
        print('success')
        print "#########################"
        succ = succ + 1
    except smtplib.SMTPException as e:
        print('error', e)  # 打印错误
    return succ


# 针对每一个样本数据生成邮件内容
# 加载数据
sample = np.loadtxt("/Users/amy/Desktop/ICSE2019/data/rq2.2_validate.csv", dtype=str, delimiter=",")
print 'sample', sample
re_list = [49, 58, 61, 81, 112, 60]

def hasNoNumbers(inputString):
    if bool(re.search(r'\d', inputString)):
        return 0
    else:
        return 1


def format(num):
    if num >= 0.01:
        re = float('%.2f' % num)
    elif num >= 0.001:
        re = float('%.3f' % num)
    elif num >= 0.0001:
        re = float('%.4f' % num)
    elif num >= 0.00001:
        re = float('%.5f' % num)
    else:
        re = float('%.6f' % num)
    print re
    return re


def cf1(mod):
    if mod == 1 or mod == 5:
        cf = "Deployment tools"
    elif mod == 2:
        cf = "Storage"
    elif mod == 3:
        cf = "Networking"
    elif mod == 4:
        cf = "Document"
    elif mod == 6 or mod == 7:
        cf = "Development tools"
    else:
        cf = "Orchestration"
    print cf
    return cf


def ccls1(mod):
    if mod == 1:
        ccls = "the companies that make substantial and extensive contributions tend to be \n" \
               "the providers of full cloud solution, and care more about deployment tools of OpenStack."
    elif mod == 2 or mod == 3 or mod == 4:
        ccls = "the companies driven by particular business needs center their contributions \n" \
               "on specific projects relevant to their business."
    elif mod == 5:
        ccls = "the companies being OpenStack users make extensive while not intensive \n" \
               "contributions, and have a preference on deployment tools."
    elif mod == 6 or mod == 8:
        ccls = "the community players such as the Linux Foundation, and research groups  \n" \
               "driven by interest are minor contributors."
    elif mod == 7:
        ccls = "Companies which contribute to specific projects are infrastructure vendors \n" \
               "developing software that support the development of OpenStack."
    print ccls
    return ccls


def obj1(mod):
    if mod == 1:
        obj = "providing users with a complete cloud solution based on OpenStack"
    elif mod == 2:
        obj = "providing cloud solution to users only on the basis of one or two \n" \
              "sub-project(s) in OpenStack."
    elif mod == 3:
        obj = "integrating OpenStack with original businesses"
    elif mod == 4:
        obj = "providing complementary services based on OpenStack"
    elif mod == 5:
        obj = "using OpenStack in production environment"
    elif mod == 6:
        obj = "living symbiotically off an open source ecosystems"
    elif mod == 7:
        obj = "providing the underlying tools to support the distributed-\n" \
              "multiplayer collaborative development of OpenStack"
    else:
        obj = "interested in the new technology brought up in OpenStack or the survival\n" \
              "mechanism of OpenStack ecosystem"
    print obj
    return obj

failed = []
count = []
success = 0
for i in range(len(sample)):
    receivers = []
    company = []
    content = ""
    details = ""
    receivers_test = ["995665142@qq.com"]

    cursor.execute("SELECT distinct name, email, count(icse19.id) "
                   "from icse19, people_new "
                   "where icse19.author_id = people_new.id_old "
                   "and icse19.company like %s "
                   "group by name, email "
                   "order by count(icse19.id) desc ", str(sample[i][0]))
    res1 = cursor.fetchall()
    print res1

    if len(res1) > 1:
        name = res1[0][0]
        CIO_cmt = format(float(sample[i][3]))*100
        CIO_dvpr = format(float(sample[i][4]))*100
        CIP_cmt = format(float(sample[i][5]))*100
        CIP_dvpr = format(float(sample[i][6]))*100
        CEP = format(float(sample[i][9]))*100
        company = str(sample[i][0])
        cf = cf1(int(sample[i][1]))
        conclusion = ccls1(int(sample[i][1]))
        obj = obj1(int(sample[i][1]))
        receivers.append(res1[1][1])

        print company

        # 构造邮件整体框架内容
        content = "Dear " + name + "," + "\n" + "I am a researcher from Peking University. I am investigating how a large-scale\n" \
                                                  "ecosystem such as OpenStack with hundreds of companies involved is formed and\n" \
                                                  "sustained. We expect our study could help people better understand the practices\n" \
                                                  "and sustain ecosystems. I would much appreciate if you would be willing to participate\n" \
                                                  "in this research work that should not take more than three minutes.\n" \
                  + "\n" + "We obtained commercial objectives of a company joining OpenStack through\n" \
                           "qualitative analysis of online documents. And we quantified the contribution of a\n" \
                           "company through its input developers and submitted commits. The following is an\n" \
                           "analysis report for " + company + ":\n" \
                  "1. Participation motivation: " + obj + "\n" \
                  "2. The performance of contributions along three dimensions:\n" \
                  " a. On average in a release of OpenStack, the developers from " + company + " account for " + str(CIO_dvpr) + "%, \n" \
                  "and the commits submitted by these developers account for " + str(CIO_cmt) + "%. In the most \n" \
                  "related sub-project of OpenStack, the developers from " + company + " account for " + str(CIP_dvpr) + "%, and \n" \
                  "the commits account for " + str(CIP_cmt) + "%.\n"\
                  " b. On average in one release, " + company + " tend to make contributions to " + str(CEP) + "% of sub-projects in OpenStack.\n" \
                  "(The above percentages are calculated based on an average performance of " + company + " in all \n" \
                  "the participated releases. We quantify companies' contributions by the developers they \n" \
                  "provide and the commits made by those developers. ）\n" \
                  " c. \"" + cf + "\" is the type of sub-projects where " + company + " most prefer to make contributions.\n\n" \
                  "Conclusion: " + conclusion + "\n"\
                  "(The conclusion is based on " + company + " and other companies that have the same motivation \n" \
                  "and similar contribution performance.)\n" \
                  "We learn that you have been an outstanding developer of " + company + ". Could you tell us your view on this conclusion?\n" \
                  "A. Strongly agree\nB. Agree\nC. Neutral\nD. Disagree\nE. Strongly disagree\n" \
                  "And why?\n" \
                  "\nYour answer is extremely important for our study! Please note your information will be \n" \
                  "kept privacy and we will only publish common statistics. \n" \
                  "Thank you very much for your time and cooperation.\n\nBest regards\nYuxia Zhang\n" \
                  "Peking University, Beijing, China"

    print 'name', name
    print 'receivers', receivers
    print 'content\n', content
    # 发送问卷
    if content != "":
        success = sendmail(content, receivers, success)
        count.append(i)
    else:
        failed.append(i)
    print "#########################", i, "#########################"
print "count", count
print "success", success
np.savetxt(path2 + "/data/failed_surveyRQ2.2.csv", failed, fmt="%d", delimiter=",")

conn.commit()
cursor.close()
conn.close()
