#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
from datetime import datetime
import csv
import numpy
import pymysql
from numpy import *
import numpy as np
from numpy import mean, median
import matplotlib.pyplot as plt
import math
import os

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='latin1')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']


# 计算熵值
def entropy(tt_dvpr, tt_cmm, data=[]):
    ep_cmm = 0
    ep_dvpr = 0
    for i in range(len(data)):
        p_dvpr = data[i][1] / tt_dvpr
        p_cmm = data[i][2] / tt_cmm
        print p_dvpr, p_cmm
        ep_dvpr += -p_dvpr * math.log(p_dvpr, 2)
        ep_cmm += -p_cmm * math.log(p_cmm, 2)

    print "ep_dvpr, ep_cmm", ep_dvpr, ep_cmm
    return ep_dvpr, ep_cmm

# 模型拟合数据收集
model_set1 = []
model_set2 = []
for i in range(14):
    start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
    end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
    print start_time, end_time

    cursor.execute("SELECT distinct repository_id "
                   "FROM icse19 "
                   "where date between %s and %s "
                   "and repo_type != 15 ", (start_time, end_time))
    res = cursor.fetchall()

    for j in range(len(res)):
        # 获取项目、总开发者数，总commit数以及项目所属类型
        cursor.execute("SELECT repository_id, count(distinct author_id), "
                       "count(distinct id), repo_type "
                       "FROM icse19 "
                       "where repository_id = %s "
                       "and date between %s and %s "
                       "and company is not null "
                       "group by repository_id, repo_type ",
                       (res[j][0], start_time, end_time))
        res1 = cursor.fetchall()
        print "res1", res1
        if res1[0][1] == 0:
            continue

        '''
        # 获取来自各个公司的开发者数，提交的commit数
        cursor.execute("SELECT company, count(distinct author_id), count(distinct id) "
                       "FROM icse19 "
                       "where repository_id = %s "
                       "and date between %s and %s "
                       "and company is not null "
                       "group by company ",
                       (res[j][0], start_time, end_time))
        res2 = cursor.fetchall()
        # 计算在公司层面的熵
        ep_com_dvpr, ep_com_cmm = entropy(res1[0][1], res1[0][2], res2)
        '''
        # 获取来自各个模型的开发者数，提交的commit数
        cursor.execute("SELECT icse19.model_8, count(distinct author_id), count(distinct id) "
                       "FROM icse19 "
                       "where repository_id = %s "
                       "and date between %s and %s "
                       "and model_8 is not null "
                       "group by icse19.model_8 "
                       "order by icse19.model_8 ",
                       (res[j][0], start_time, end_time))
        res3 = cursor.fetchall()
        if len(res3) == 0:
            continue
        ep_mod_dvpr, ep_mod_cmm = entropy(res1[0][1], res1[0][2], res3)

        # 计算志愿者数
        cursor.execute("SELECT count(distinct author_id), count(distinct id) "
                       "FROM icse19 "
                       "where repository_id = %s "
                       "and date between %s and %s "
                       "and company like 'independent' ",
                       (res[j][0], start_time, end_time))
        res4 = cursor.fetchall()
        if res4[0][0] == 0:
            continue

        # model_set1.append([i+1, res1[0][0], res1[0][1], res1[0][2], res1[0][3],
                          # ep_com_dvpr, ep_com_cmm, res4[0][0], res4[0][1]])
        model_set2.append([i+1, res1[0][0], res1[0][1], res1[0][2], res1[0][3],
                           ep_mod_dvpr, ep_mod_cmm, res4[0][0], res4[0][1]])
        # print "model_set1", model_set1
        print "model_set2", model_set2

# np.savetxt(path2 + "/data/model_set1_82.csv", model_set1, fmt="%f", delimiter=",")
np.savetxt(path2 + "/data/model_set8_82.csv", model_set2, fmt="%f", delimiter=",")


