#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
from datetime import datetime
import csv
import numpy
import pymysql
from numpy import *
import numpy as np
from numpy import mean, median
import matplotlib.pyplot as plt
import math
import os
import seaborn as sns
import pandas as pd

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='latin1')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']


def write_data(fileName="", dataList=[]):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in dataList:
            data = [unicode(s).encode("utf-8") for s in data]
            csvWriter.writerow(data)
        csvFile.close


def extra_date(num1, num2, re):
    if num1 > 0:
        re.append(num1/num2)
    return re

cursor.execute("SELECT distinct company, model_6, count(distinct id) "
               "FROM icse19 "
               "where model_6 is not null "
               "group by company, model_6 "
               "order by count(distinct id) desc ")
coms_list = cursor.fetchall()
print 'coms_list', coms_list


write_data(path2 + "/data/company_model6_27.csv", coms_list)

intensity = []
extent = []
interest_repo = []
interest_repoT = []
ci_ce = []
for i in range(len(coms_list)):
    print '#########', coms_list[i][0], '##########', i, '#########'
    iy_perV_whole_cmt = []
    iy_perV_whole_dvp = []
    iy_perV_repo_cmt = []
    iy_perV_repo_dvp = []
    iy_perV_repoT_cmt = []
    iy_perV_repoT_dvp = []
    et_perV_repo = []
    et_perV_repoT = []

    ci_repoT_name = []
    ci_repoT_value = []

    for j in range(14):
        start_time = datetime.date(datetime.strptime(version_date[j], '%Y-%m-%d'))
        end_time = datetime.date(datetime.strptime(version_date[j + 1], '%Y-%m-%d'))
        print start_time, end_time
        # 计算公司对整个openstack的贡献力度
        cursor.execute("SELECT count(distinct id), count(distinct author_id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 ", (coms_list[i][0], start_time, end_time))
        res1 = cursor.fetchall()
        if res1[0][0] == 0:
            continue
        cursor.execute("SELECT count(distinct id), count(distinct author_id) "
                       "FROM icse19 "
                       "where date between %s and %s "                     
                       "and repo_type != 15 ", (start_time, end_time))
        res2 = cursor.fetchall()
        iy_perV_whole_cmt = extra_date(res1[0][0], res2[0][0], iy_perV_whole_cmt)
        iy_perV_whole_dvp = extra_date(res1[0][1], res2[0][1], iy_perV_whole_dvp)

        print 'iy_perV_whole_cmt', iy_perV_whole_cmt
        print 'iy_perV_whole_dvp', iy_perV_whole_dvp
        print res1[0][0], res2[0][0]
        cio_c = res1[0][0] / res2[0][0]
        cio_d = res1[0][1] / res2[0][1]
        # 计算公司对特定openstack repo的贡献力度
        cursor.execute("SELECT repository_id, count(distinct id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repository_id "
                       "order by count(distinct id) desc ", (coms_list[i][0], start_time, end_time))
        res3 = cursor.fetchall()

        if len(res3) > 0:
            cursor.execute("SELECT count(distinct id) "
                           "FROM icse19 "
                           "where repository_id = %s "
                           "and date between %s and %s "
                           "and repo_type != 15 ", (res3[0][0], start_time, end_time))
            res4 = cursor.fetchall()

            iy_perV_repo_cmt = extra_date(res3[0][1], res4[0][0], iy_perV_repo_cmt)
            cip_c = res3[0][1] / res4[0][0]
        print 'iy_perV_repo_cmt', iy_perV_repo_cmt

        cursor.execute("SELECT repository_id, count(distinct author_id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repository_id "
                       "order by count(distinct author_id) desc ", (coms_list[i][0], start_time, end_time))
        res5 = cursor.fetchall()
        if len(res5) > 0:
            cursor.execute("SELECT count(distinct author_id) "
                           "FROM icse19 "
                           "where repository_id = %s "
                           "and date between %s and %s "
                           "and repo_type != 15 ", (res5[0][0], start_time, end_time))
            res6 = cursor.fetchall()

            iy_perV_repo_dvp = extra_date(res5[0][1], res6[0][0], iy_perV_repo_dvp)
            cip_d = res5[0][1] / res6[0][0]
        print 'iy_perV_repo_dvp', iy_perV_repo_dvp

        # 计算公司对特定openstack repo type的贡献力度
        cursor.execute("SELECT repo_type, count(distinct id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repo_type "
                       "order by count(distinct id) desc ", (coms_list[i][0], start_time, end_time))
        res7 = cursor.fetchall()
        if len(res7) > 0:
            cursor.execute("SELECT count(distinct id) "
                           "FROM icse19 "
                           "where repo_type = %s "
                           "and date between %s and %s ", (res7[0][0], start_time, end_time))
            res8 = cursor.fetchall()

            iy_perV_repoT_cmt = extra_date(res7[0][1], res8[0][0], iy_perV_repoT_cmt)
            cit_c = res7[0][1] / res8[0][0]
        print 'iy_perV_repoT_cmt', iy_perV_repoT_cmt

        cursor.execute("SELECT repo_type, count(distinct author_id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repo_type "
                       "order by count(distinct author_id) desc ", (coms_list[i][0], start_time, end_time))
        res9 = cursor.fetchall()
        if len(res9) > 0:
            cursor.execute("SELECT count(distinct author_id) "
                           "FROM icse19 "
                           "where repo_type = %s "
                           "and date between %s and %s ", (res9[0][0], start_time, end_time))
            res10 = cursor.fetchall()

            iy_perV_repoT_dvp = extra_date(res9[0][1], res10[0][0], iy_perV_repoT_dvp)
            cit_d = res9[0][1] / res10[0][0]
        print 'iy_perV_repoT_dvp', iy_perV_repoT_dvp

        # 计算公司做贡献的广度
        cursor.execute("SELECT count(distinct repository_id), count(distinct repo_type) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 ", (coms_list[i][0], start_time, end_time))
        res11 = cursor.fetchall()

        cursor.execute("SELECT count(distinct repository_id), count(distinct repo_type) "
                       "FROM icse19 "
                       "where date between %s and %s "
                       "and repo_type != 15 ", (start_time, end_time))
        res12 = cursor.fetchall()

        et_perV_repo = extra_date(res11[0][0], res12[0][0], et_perV_repo)
        et_perV_repoT = extra_date(res11[0][1], res12[0][1], et_perV_repoT)
        ce_p = res11[0][0] / res12[0][0]
        ce_t = res11[0][1] / res12[0][1]
        print 'et_perV_repo', et_perV_repo
        print 'et_perV_repoT', et_perV_repoT 

        # 计算在类型粒度上的贡献兴趣
        cursor.execute("SELECT repo_type, count(distinct id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repo_type "
                       "order by count(distinct id) desc ", (coms_list[i][0], start_time, end_time))
        res14 = cursor.fetchall()
        print 'interest repoT ', res14
        print "len(res14)", len(res14)
        if len(res14) > 0:
            if len(res14) < 10:
                if res14[0][0] in ci_repoT_name:
                    ci_repoT_value[ci_repoT_name.index(res14[0][0])] += 1
                else:
                    ci_repoT_name.append(res14[0][0])
                    ci_repoT_value.append(1)
            else:
                for r in range(int(len(res14)*0.1)):
                    if res14[r][0] in ci_repoT_name:
                        ci_repoT_value[ci_repoT_name.index(res14[r][0])] += 1
                    else:
                        ci_repoT_name.append(res14[r][0])
                        ci_repoT_value.append(1)
        print ci_repoT_name
        print ci_repoT_value

        ci_ce.append([coms_list[i][1], cio_d, cio_c, cit_d, cit_c, cip_d, cip_c, ce_p, ce_t])

    intensity.append([mean(iy_perV_whole_cmt), mean(iy_perV_whole_dvp),
                      median(iy_perV_whole_cmt), median(iy_perV_whole_dvp),
                      mean(iy_perV_repo_cmt), mean(iy_perV_repo_dvp),
                      median(iy_perV_repo_cmt), median(iy_perV_repo_dvp),
                      mean(iy_perV_repoT_cmt), mean(iy_perV_repoT_dvp),
                      median(iy_perV_repoT_cmt), median(iy_perV_repoT_dvp)])

    extent.append([mean(et_perV_repo), mean(et_perV_repoT), median(et_perV_repo),
                   median(et_perV_repoT)])

    #interest_repo.append([ci_repo_name, ci_repo_value])
    interest_repoT.append([ci_repoT_name, ci_repoT_value])

print 'intensity: ', intensity
print 'extent: ', extent
print 'interest_repo: ', interest_repo
print 'interest_repoT: ', interest_repoT

write_data(path2 + "/data/intensity6_27.csv", intensity)
write_data(path2 + "/data/extent6_27.csv", extent)
write_data(path2 + "/data/interest_repo6_27.csv", interest_repo)
write_data(path2 + "/data/interest_repoT6_27.csv", interest_repoT)
write_data(path2 + "/data/ci_ce_27.csv", ci_ce)
'''

# 按照模型处理数据
dataset = np.loadtxt(path2 + "/data/RQ2.2_6(1).csv", delimiter=',', dtype=float, unpack=True)
print dataset

print dataset[1]
print dataset[2][0:38]
# 各个模型的个数
index = [0, 39, 77, 100, 102, 105, 133]
mean_model_result = []
median_model_result = []
for i in range(6):
    data_mean = []
    data_median = []
    for j in range(0, 16):
        # data = float(dataset[j][0: len(dataset[j]-1)])
        print "index[i]", index[i]
        print "index[i+1]", index[i+1]
        print dataset[j][index[i]:index[i+1]]
        data_mean.append(mean(dataset[j][index[i]:index[i+1]]))
        data_median.append(median(dataset[j][index[i]:index[i+1]]))
        # print "data_mean", data_mean
        # print "data_meandian", data_median
    mean_model_result.append(data_mean)
    median_model_result.append(data_median)
print "mean_model_result\n", mean_model_result
print "median_model_result\n", median_model_result


write_data(path2 + "/data/mean_model6_result.csv", mean_model_result)
write_data(path2 + "/data/median_model6_result.csv", median_model_result)


# 可视化结果
ci_ce = pd.read_csv(path2 + "/data/ci_ce_23.csv")
print ci_ce
sns.set(style="whitegrid")
ax = sns.violinplot(x="model", y="cio", hue="contribution type", data=ci_ce, palette="Set2")

sns.plt.show()
'''


conn.commit()
cursor.close()
conn.close()