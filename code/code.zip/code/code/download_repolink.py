#!/usr/bin/python
# -*- coding: UTF-8 -*-
from bs4 import BeautifulSoup
import numpy as np
import requests

urls = ['https://github.com/openstack?page={}'.format(str(i)) for i in range(1, 57)]
print urls
print len(urls)


def get_titles(url, full_links=[]):
    # full_links = []
    prefix = 'https://github.com/openstack/'
    web_data = requests.get(url)

    soup = BeautifulSoup(web_data.text, 'lxml')
    links = soup.findAll("a", attrs={"itemprop": "name codeRepository"})

    for link in links:
        print "link", link
        print link.get_text()
        link_full = prefix+str(link.get_text()).replace("\n", "").replace(" ", "")
        print 'link_full', link_full
        full_links.append(link_full)
    print 'full_links\n', full_links
    print '####################', len(full_links)
    return full_links

full_links = []
for j in range(1, 56):
    get_titles(urls[j], full_links)
print 'num_full_links\n', len(full_links)

np.savetxt("/Users/amy/Desktop/ICSE2019/data/repo_links2.csv", full_links, delimiter=',', fmt='%s')
