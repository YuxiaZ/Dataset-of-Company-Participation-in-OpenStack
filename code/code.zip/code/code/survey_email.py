#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys
import smtplib
from email.mime.text import MIMEText
import re

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='latin1')
cursor = conn.cursor()


def sendmail(content, receivers, succ):
    # 设置服务器所需信息
    # 163邮箱服务器地址
    mail_host = 'smtp.163.com'
    # 163用户名
    mail_user = 'yuxia_pku@163.com'
    # 密码(部分邮箱为授权码)
    mail_pass = '2011118066zyx'
    # 邮件发送方邮箱地址
    sender = 'yuxia_pku@163.com'
    # 邮件接受方邮箱地址，注意需要[]包裹，这意味着你可以写多个邮件地址群发
    receivers = receivers

    # 设置email信息
    # 邮件内容设置

    message = MIMEText(content, 'plain', 'utf8')
    # 邮件主题
    message['Subject'] = 'A Simple Validation of Your Contributions to OpenStack'
    # 发送方信息
    message['From'] = sender
    # 接受方信息
    # message['To'] = receivers[0]
    message['To'] = ';'.join(receivers)

    # 登录并发送邮件
    try:
        smtpObj = smtplib.SMTP()
        #smtpObj = smtplib.SMTP_SSL('smtp.163.com')
        # 连接到服务器
        smtpObj.connect(mail_host, 25)
        smtpObj.set_debuglevel(1)
        # 登录到服务器
        #smtpObj.ehlo()
        #smtpObj.starttls()
        smtpObj.login(mail_user, mail_pass)
        # 发送
        smtpObj.sendmail(
            sender, receivers, message.as_string())
        # 退出
        smtpObj.quit()
        print "#########################"
        print('success')
        print "#########################"
        succ = succ + 1
    except smtplib.SMTPException as e:
        print('error', e)  # 打印错误
    return succ


# 针对每一个样本数据生成邮件内容
# 加载数据
sample = np.loadtxt("/Users/amy/Desktop/ICSE2019/data/sample.csv", dtype=np.int, delimiter=",")
print 'sample', sample

sample2 = np.loadtxt("/Users/amy/Desktop/ICSE2019/data/sample2.csv", dtype=np.int, delimiter=",")
print 'sample2', sample2

sample3 = np.loadtxt("/Users/amy/Desktop/ICSE2019/data/sample3.csv", dtype=np.int, delimiter=",")
print 'sample3', sample3


def hasNoNumbers(inputString):
    if bool(re.search(r'\d', inputString)):
        return 0
    else:
        return 1


failed = []
count = 0
success = 0
for i in range(796, len(sample3)):
    receivers = []
    company = []
    content = ""
    details = ""
    receivers_test = ["995665142@qq.com"]
    flag = 1
    # 检验是否已经发送过邮件
    print sample3[i]
    if sample3[i] in sample:
        print "$$$$$$$$$$$$$$$$$$$$$"
        continue
    if sample3[i] in sample2:
        print "$$$$$$$$$$$$$$$$$$$$$"
        continue

    cursor.execute("SELECT distinct * "
                   "FROM people_new "
                   "where id like %s ", int(sample3[i]))
    res1 = cursor.fetchall()
    print res1

    # 计算该贡献者所属的公司个数
    cursor.execute("SELECT distinct company "
                   "FROM dvpr_com "
                   "where people_id = %s ", int(sample3[i]))
    res4 = cursor.fetchall()
    print res4
    com_list = []
    for d in range(len(res4)):
        com_list.append(res4[d][0])
    print 'com_list', com_list
    if len(com_list) == 0:
        continue
    # print 'com_list[0]', com_list[0]
    # print 'com_list[0][0]', com_list[0][0]
    name = res1[0][2]
    commits = []
    # 统计每个身份commit
    for j in range(len(res1)):
        if len(res1[j][2]) > len(name) and hasNoNumbers(res1[j][2]):
            name = res1[j][2]
        # 收件人
        if res1[j][3] not in receivers:
            receivers.append(res1[j][3])
        # 随机抽取commit
        cursor.execute("SELECT distinct icse19.rev, repositories.uri, icse19.company "
                       "FROM icse19, repositories "
                       "where icse19.author_id = %s "
                       "and icse19.repository_id = repositories.id "
                       "and uri like 'https://github%%'", res1[j][1])
        res2 = cursor.fetchall()
        print 'res2', res2
        print len(res2)
        if len(res2) == 0:
            continue
        elif len(res2) == 1:
            commits.append(res2[0])
            if res2[0][2] in com_list:
                com_list.remove(res2[0][2])
        else:
            sp = random.randint(0, len(res2) - 1)
            commits.append(res2[sp])
            if res2[0][2] in com_list:
                com_list.remove(res2[sp][2])
        print "com_list", com_list

    if len(com_list) > 0:
        for n in range(len(com_list)):
            cursor.execute("SELECT distinct icse19.rev, repositories.uri, icse19.company "
                           "FROM icse19, repositories "
                           "where icse19.author_id = %s "
                           "and icse19.company like %s "
                           "and icse19.repository_id = repositories.id "
                           "and uri like 'https://github%%'", (res1[j][1], com_list[n]))
            res3 = cursor.fetchall()
            if len(res3) == 0:
                continue
            elif len(res3) == 1:
                commits.append(res3[0])
            else:
                sp = random.randint(0, len(res3) - 1)
                commits.append(res3[sp])

    if len(commits) > 0:
        # 构造问题的details内容（commit）
        for e in range(len(commits)):
            if ".git" in commits[e][1]:
                html = commits[e][1][:-4]
            else:
                html = commits[e][1]
            if commits[e][2] == 'independent':
                details = details + "\n" + html + "/commit/" + commits[e][0] + "\n" + "Yes| No | Not Sure" + \
                          "\n" + "During this period, you are a volunteer in OpenStack. " + "\n" \
                          + "Yes| No | Not Sure" + "\n"
            else:
                details = details + "\n" + html + "/commit/" + commits[e][0] + "\n" + "Yes| No | Not Sure" + \
                          "\n" + "During this period, you are hired by " + "__" + commits[e][2] + "__" + "\n" \
                          + "Yes| No | Not Sure" + "\n"

    # 构造邮件整体框架内容
    content = "Dear " + name + "," + "\n\n" + "I am a researcher in the school of electronics engineering and computer science\n" \
                                              "at Peking University. I’m investigating how a large-scale ecosystem such as\n" \
                                              "OpenStack with hundreds of companies involved is formed and sustained. We expect\n" \
                                              "our study could help people better understand the practices and sustain ecosystems.\n" \
                                              "I would appreciate if you would be willing to participate in this research study that\n" \
                                              "should not take more than three minutes of your time.\n" \
              + "\n" + "I would much appreciate it if you could please indicate which of the following\n" \
                       "randomly selected commits were made by you, and whether the company you belong\n" \
                       "to is right or not:\n" \
              + details \
              + "\n" + "Your answer is extremely important for our study! Please note your information " \
                       "will be kept \nprivacy and we will only publish common statistics. " + "\n\n" + \
              "Thank you very much for your time and cooperation." + "\n\n" + "Best regards\n\n" + \
              "Yuxia Zhang" + "\n" + "Peking University, Beijing, China"

    print 'name', name
    print 'receivers', receivers
    print 'content\n', content
    # 发送问卷
    if details != "":
        success = sendmail(content, receivers, success)
        count = count + 1
    else:
        failed.append(int(sample3[i]))
    if success == 60:
        break
print "count", count
print "success", success
print failed
np.savetxt(path2 + "/data/failed_survey2.csv", failed, fmt="%d", delimiter=",")

conn.commit()
cursor.close()
conn.close()
