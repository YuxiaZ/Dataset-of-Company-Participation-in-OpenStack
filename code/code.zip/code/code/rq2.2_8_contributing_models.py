#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
from datetime import datetime
import csv
import numpy
import pymysql
from numpy import *
import numpy as np
from numpy import mean, median
import matplotlib.pyplot as plt
import math
import os
import seaborn as sns
import pandas as pd

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='latin1')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']


def write_data(fileName="", dataList=[]):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in dataList:
            data = [unicode(s).encode("utf-8") for s in data]
            csvWriter.writerow(data)
        csvFile.close


def extra_date(num1, num2, re):
    if num1 > 0:
        re.append(num1/num2)
    return re

cursor.execute("SELECT distinct company, model_8, count(distinct id) "
               "FROM icse19 "
               "where model_8 is not null "
               "group by company, model_8 "
               "order by count(distinct id) desc ")
coms_list = cursor.fetchall()
print 'coms_list', coms_list
write_data(path2 + "/data/company_model8_27.csv", coms_list)


intensity = []
extent = []
interest_repo = []
interest_repoT = []

for i in range(len(coms_list)):
    print '#################', coms_list[i][0], '#################'
    iy_perV_whole_cmt = []
    iy_perV_whole_dvp = []
    iy_perV_repo_cmt = []
    iy_perV_repo_dvp = []
    iy_perV_repoT_cmt = []
    iy_perV_repoT_dvp = []
    et_perV_repo = []
    et_perV_repoT = []

    ci_repo_name = []
    ci_repo_value = []
    ci_repoT_name = []
    ci_repoT_value = []

    for j in range(14):
        start_time = datetime.date(datetime.strptime(version_date[j], '%Y-%m-%d'))
        end_time = datetime.date(datetime.strptime(version_date[j + 1], '%Y-%m-%d'))
        print start_time, end_time
        '''
        # 计算公司对整个openstack的贡献力度
        cursor.execute("SELECT count(distinct id), count(distinct author_id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 ", (coms_list[i][0], start_time, end_time))
        res1 = cursor.fetchall()
        if len(res1) == 0:
            continue
        cursor.execute("SELECT count(distinct id), count(distinct author_id) "
                       "FROM icse19 "
                       "where date between %s and %s "                     
                       "and repo_type != 15 ", (start_time, end_time))
        res2 = cursor.fetchall()
        iy_perV_whole_cmt = extra_date(res1[0][0], res2[0][0], iy_perV_whole_cmt)
        iy_perV_whole_dvp = extra_date(res1[0][1], res2[0][1], iy_perV_whole_dvp)

        print 'iy_perV_whole_cmt', iy_perV_whole_cmt
        print 'iy_perV_whole_dvp', iy_perV_whole_dvp

        # 计算公司对特定openstack repo的贡献力度
        cursor.execute("SELECT repository_id, count(distinct id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repository_id "
                       "order by count(distinct id) desc ", (coms_list[i][0], start_time, end_time))
        res3 = cursor.fetchall()

        if len(res3) > 0:
            cursor.execute("SELECT count(distinct id) "
                           "FROM icse19 "
                           "where repository_id = %s "
                           "and date between %s and %s "
                           "and repo_type != 15 ", (res3[0][0], start_time, end_time))
            res4 = cursor.fetchall()

            iy_perV_repo_cmt = extra_date(res3[0][1], res4[0][0], iy_perV_repo_cmt)
        print 'iy_perV_repo_cmt', iy_perV_repo_cmt

        cursor.execute("SELECT repository_id, count(distinct author_id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repository_id "
                       "order by count(distinct author_id) desc ", (coms_list[i][0], start_time, end_time))
        res5 = cursor.fetchall()
        if len(res5) > 0:
            cursor.execute("SELECT count(distinct author_id) "
                           "FROM icse19 "
                           "where repository_id = %s "
                           "and date between %s and %s "
                           "and repo_type != 15 ", (res5[0][0], start_time, end_time))
            res6 = cursor.fetchall()

            iy_perV_repo_dvp = extra_date(res5[0][1], res6[0][0], iy_perV_repo_dvp)
        print 'iy_perV_repo_dvp', iy_perV_repo_dvp

        # 计算公司对特定openstack repo type的贡献力度
        cursor.execute("SELECT repo_type, count(distinct id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repo_type "
                       "order by count(distinct id) desc ", (coms_list[i][0], start_time, end_time))
        res7 = cursor.fetchall()
        if len(res7) > 0:
            cursor.execute("SELECT count(distinct id) "
                           "FROM icse19 "
                           "where repo_type = %s "
                           "and date between %s and %s ", (res7[0][0], start_time, end_time))
            res8 = cursor.fetchall()

            iy_perV_repoT_cmt = extra_date(res7[0][1], res8[0][0], iy_perV_repoT_cmt)
        print 'iy_perV_repoT_cmt', iy_perV_repoT_cmt

        cursor.execute("SELECT repo_type, count(distinct author_id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repo_type "
                       "order by count(distinct author_id) desc ", (coms_list[i][0], start_time, end_time))
        res9 = cursor.fetchall()
        if len(res9) > 0:
            cursor.execute("SELECT count(distinct author_id) "
                           "FROM icse19 "
                           "where repo_type = %s "
                           "and date between %s and %s ", (res9[0][0], start_time, end_time))
            res10 = cursor.fetchall()

            iy_perV_repoT_dvp = extra_date(res9[0][1], res10[0][0], iy_perV_repoT_dvp)
        print 'iy_perV_repoT_dvp', iy_perV_repoT_dvp

        # 计算公司对项目做贡献的广度
        cursor.execute("SELECT count(distinct repository_id), count(distinct repo_type) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 ", (coms_list[i][0], start_time, end_time))
        res11 = cursor.fetchall()

        cursor.execute("SELECT count(distinct repository_id), count(distinct repo_type) "
                       "FROM icse19 "
                       "where date between %s and %s "
                       "and repo_type != 15 ", (start_time, end_time))
        res12 = cursor.fetchall()

        et_perV_repo = extra_date(res11[0][0], res12[0][0], et_perV_repo)
        et_perV_repoT = extra_date(res11[0][1], res12[0][1], et_perV_repoT)
        print 'et_perV_repo', et_perV_repo
        print 'et_perV_repoT', et_perV_repoT
        '''
        # 计算在类型粒度上的贡献兴趣
        cursor.execute("SELECT repo_type, count(distinct id) "
                       "FROM icse19 "
                       "where company like %s "
                       "and date between %s and %s "
                       "and repo_type != 15 "
                       "group by repo_type "
                       "order by count(distinct id) desc ", (coms_list[i][0], start_time, end_time))
        res14 = cursor.fetchall()
        print 'interest repoT ', res14
        if len(res14) >= 10:
            for r in range(int(len(res14)*0.1)):
                if res14[r][0] in ci_repoT_name:
                    ci_repoT_value[ci_repoT_name.index(res14[r][0])] += 1
                else:
                    ci_repoT_name.append(res14[r][0])
                    ci_repoT_value.append(1)
        elif 0 < len(res14) < 10:
            if res14[0][0] in ci_repoT_name:
                ci_repoT_value[ci_repoT_name.index(res14[0][0])] += 1
            else:
                ci_repoT_name.append(res14[0][0])
                ci_repoT_value.append(1)
    '''
    intensity.append([mean(iy_perV_whole_cmt), mean(iy_perV_whole_dvp),
                      median(iy_perV_whole_cmt), median(iy_perV_whole_dvp),
                      mean(iy_perV_repo_cmt), mean(iy_perV_repo_dvp),
                      median(iy_perV_repo_cmt), median(iy_perV_repo_dvp),
                      mean(iy_perV_repoT_cmt), mean(iy_perV_repoT_dvp),
                      median(iy_perV_repoT_cmt), median(iy_perV_repoT_dvp)])

    extent.append([mean(et_perV_repo), mean(et_perV_repoT), median(et_perV_repo),
                   median(et_perV_repoT)])
    '''
    #interest_repo.append([ci_repo_name, ci_repo_value])
    interest_repoT.append([ci_repoT_name, ci_repoT_value])
    print "###############interest_repoT##############\n", interest_repoT

print 'intensity: ', intensity
print 'extent: ', extent
print 'interest_repo: ', interest_repo
print 'interest_repoT: ', interest_repoT

#write_data(path2 + "/data/intensity8_727.csv", intensity)
#write_data(path2 + "/data/extent8_727.csv", extent)
#write_data(path2 + "/data/interest_repo8_727.csv", interest_repo)
write_data(path2 + "/data/interest_repoT8_727.csv", interest_repoT)


'''
# 按照模型处理数据
dataset = np.loadtxt(path2 + "/data/RQ2.2.csv", delimiter=',', dtype=float, unpack=True, skiprows=1)
print dataset

print dataset[1]
print dataset[2][0:38]
# 各个模型的个数
index = [0, 38, 51, 69, 74, 96, 99, 102, 110]
mean_model_result = []
median_model_result = []
for i in range(8):
    data_mean = []
    data_median = []
    for j in range(0, 16):
        # data = float(dataset[j][0: len(dataset[j]-1)])
        print "index[i]", index[i]
        print "index[i+1]", index[i+1]
        data_mean.append(mean(dataset[j][index[i]:index[i+1]]))
        data_median.append(median(dataset[j][index[i]:index[i+1]]))
        # print "data_mean", data_mean
        # print "data_meandian", data_median
    mean_model_result.append(data_mean)
    median_model_result.append(data_median)
print "mean_model_result\n", mean_model_result
print "median_model_result\n", median_model_result


write_data(path2 + "/data/mean_model8_result.csv", mean_model_result)
write_data(path2 + "/data/median_model8_result.csv", median_model_result)

# 可视化结果

mean_model_result = np.loadtxt(path2 + "/data/mean_model8_result.csv", delimiter=',', dtype=float)
print mean_model_result

median_model_result = np.loadtxt(path2 + "/data/median_model8_result.csv", delimiter=',', dtype=float)
print median_model_result

# 可视化结果
ci_ce = pd.read_csv(path2 + "/data/ci_ce_28.csv")
print ci_ce
sns.boxplot(x="model", y="CIO_mean", hue="type", data=ci_ce, palette="Set2")
sns.plt.show()

sns.boxplot(x="model", y="CIO_median", hue="type", palette="Set2", data=ci_ce)
sns.plt.show()

sns.boxplot(x="model", y="CIP_mean", hue="type", data=ci_ce, palette="Set2")
sns.plt.show()

sns.boxplot(x="model", y="CIP_median", hue="type", palette="Set2", data=ci_ce)
sns.plt.show()

sns.boxplot(x="model", y="CIT_mean", hue="type", data=ci_ce, palette="Set2")
sns.plt.show()

sns.boxplot(x="model", y="CIT_median", hue="type", palette="Set2", data=ci_ce)
sns.plt.show()


sns.plt.show()
'''

conn.commit()
cursor.close()
conn.close()