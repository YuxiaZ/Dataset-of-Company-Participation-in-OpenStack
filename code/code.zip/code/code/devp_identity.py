#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='latin1')
cursor = conn.cursor()


# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        print "dataLine", dataLine
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            print "tmpList", tmpList[1]
            ID = tmpList[0][1:]
            print "ID", ID
            name = tmpList[1]
            email = tmpList[2][:len(tmpList[2])-2]
            print "email", email
            dataList.append((ID, name, email))
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList

'''
dvpr_list = readListCSV("/Users/amy/Desktop/ICSE2019/data/dvpr.csv")
print "dvpr_list", dvpr_list[0]

for i in range(len(dvpr_list)):  # 将Audris的结果写入表中
    print "dvpr_list[i]", dvpr_list[i][0]
    print len(dvpr_list[i])
    cursor.execute('INSERT INTO developers(ID, name, email) values(%s,%s,%s)', (dvpr_list[i][0], dvpr_list[i][1], dvpr_list[i][2]))
# cursor.executemany('INSERT INTO developers(ID, name, email) values(%s,%s, %s)', dvpr_list)
'''

# 通过判断名字和邮箱是否相同合并开发者
# 从Audris的结果中获取同一身份的名字和邮箱集合
for i in range(10788):
    if i == 0:
        continue
    cursor.execute("SELECT * "
                   "FROM developers "
                   "where ID = %s ", i)
    res1 = cursor.fetchall()

    name_list = []
    email_list = []

    for j in range(len(res1)):
        if res1[j][1] not in name_list:
            name_list.append(res1[j][1])

        if res1[j][2] not in email_list:
            email_list.append(res1[j][2])

    print name_list
    print email_list

    cursor.execute("SELECT * "
                   "FROM people "
                   "where name in %s or email in %s "
                   "order by id ", (name_list, email_list))
    res2 = cursor.fetchall()
    print 'res2', res2
    if len(res2) == 0:
        continue
    ID = res2[0][0]
    for h in range(len(res2)):
        cursor.execute('INSERT INTO people_new values(%s,%s,%s,%s)',
                       (ID, res2[h][0], res2[h][1], res2[h][2]))
    '''
    P_id_list = []
    P_name_list = []
    P_email_list = []
    for h in range(len(res2)):
        if res2[h][0] not in P_id_list:
            P_id_list.append(res2[h][0])

        if res2[h][1] not in P_name_list:
            P_name_list.append(res2[h][1])

        if res2[h][2] not in P_email_list:
            P_email_list.append(res2[h][2])

    print "P_id_list", P_id_list
    print "P_name_list", P_name_list
    print "P_email_list", P_email_list
    '''

conn.commit()
cursor.close()
conn.close()



