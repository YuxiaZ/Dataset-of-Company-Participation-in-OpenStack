#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
from datetime import datetime
import csv
import numpy
import pymysql
from numpy import *
import numpy as np
from numpy import mean, median
import matplotlib.pyplot as plt
import math
import os
import seaborn as sns


path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='latin1')
cursor = conn.cursor()

version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']

# RQ1: 公司和志愿者在人力投入上的比值
com_manpower = []
idp_manpower = []
com_commit = []
idp_commit = []
# pct_dvpr = []
# pct_cmt = []

for i in range(14):  # 按照版本获取公司参与
    start_time = datetime.date(datetime.strptime(version_date[i], '%Y-%m-%d'))
    end_time = datetime.date(datetime.strptime(version_date[i + 1], '%Y-%m-%d'))
    print start_time, end_time
    cursor.execute("SELECT count(distinct author_id), count(distinct id) "
                   "FROM icse19 "
                   "where date between %s and %s "
                   "and company is not null "
                   "and company not like 'independent' ", (start_time, end_time))

    res1 = cursor.fetchall()
    com_manpower.append(res1[0][0])
    com_commit.append(res1[0][1])

    cursor.execute("SELECT count(distinct author_id), count(distinct id) "
                   "FROM icse19 "
                   "where date between %s and %s "
                   "and company like 'independent' ", (start_time, end_time))

    res2 = cursor.fetchall()
    idp_manpower.append(res2[0][0])
    idp_commit.append(res2[0][1])
    #pct_dvpr.append(res1[0][0]/res2[0][0])
    #pct_cmt.append(res1[0][1]/res2[0][1])


print "com_manpower\n", com_manpower
print "idp_manpower\n", idp_manpower
print "com_commit\n", com_commit
print "idp_commit\n", idp_commit

np.savetxt(path2 + "/data/com_manpower.csv", com_manpower, fmt="%f", delimiter=",")
np.savetxt(path2 + "/data/idp_manpower.csv", idp_manpower, fmt="%f", delimiter=",")
np.savetxt(path2 + "/data/com_commit.csv", com_commit, fmt="%f", delimiter=",")
np.savetxt(path2 + "/data/idp_commit.csv", idp_commit, fmt="%f", delimiter=",")

# 获取基本的统计数据
mean_com_manpower = mean(com_manpower)
mean_idp_manpower = mean(idp_manpower)
mean_com_commit = mean(com_commit)
mean_idp_commit = mean(idp_commit)

median_com_manpower = median(com_manpower)
median_idp_manpower = median(idp_manpower)
median_com_commit = median(com_commit)
median_idp_commit = median(idp_commit)

max_com_manpower = max(com_manpower)
max_idp_manpower = max(idp_manpower)
max_com_commit = max(com_commit)
max_idp_commit = max(idp_commit)

min_com_manpower = min(com_manpower)
min_idp_manpower = min(idp_manpower)
min_com_commit = min(com_commit)
min_idp_commit = min(idp_commit)

print "mean_com_manpower: ", mean_com_manpower
print "mean_idp_manpower: ", mean_idp_manpower
print "mean_com_commit: ", mean_com_commit
print "mean_idp_commit: ", mean_idp_commit

print "median_com_manpower: ", median_com_manpower
print "median_idp_manpower: ", median_idp_manpower
print "median_com_commit: ", median_com_commit
print "median_idp_commit: ", median_idp_commit

print "max_com_manpower: ", max_com_manpower
print "max_idp_manpower: ", max_idp_manpower
print "max_com_commit: ", max_com_commit
print "max_idp_commit: ", max_idp_commit

print "min_com_manpower: ", min_com_manpower
print "min_idp_manpower: ", min_idp_manpower
print "min_com_commit: ", min_com_commit
print "min_idp_commit: ", min_idp_commit

# 绘制图像
figsize = 6, 4
plt.figure(figsize=figsize)
release = range(0, len(com_manpower))
rel = [i + 0.3 for i in release]
plt.bar(release, com_manpower, color='black', width=.3, alpha=0.6, edgecolor="black", label='Hired by companies')
plt.bar(rel, idp_manpower, color='darkgrey', width=.3, alpha=0.4, edgecolor="black", label='Volunteers')
plt.xlabel('release')
plt.ylabel('# of developers')
plt.legend(loc='upper left')
#plt.grid(True, linestyle="dashdot")
plt.xticks(range(0, 14), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])
plt.savefig(path2 + "/figure/test.pdf", format='pdf')
plt.show()

plt.figure()
release = range(0, len(com_commit))
rel = [i + 0.3 for i in release]
plt.bar(release, com_commit, color='black', width=.3, alpha=0.6, edgecolor="black", label='Hired by companies')
plt.bar(rel, idp_commit, color='darkgrey', width=.3, alpha=0.4, edgecolor="black", label='Independent volunteers')
plt.xlabel('release')
plt.ylabel('# of commits')
# plt.title('XX事件数周分布')
plt.legend(loc='upper left')
# plt.grid(True, linestyle="dashdot")
plt.xticks(range(0, 14), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])
plt.savefig(path2 + "/figure/The number of commits submitted by companies and volunteers in OpenStack.pdf", format='pdf')
plt.show()


conn.commit()
cursor.close()
conn.close()



