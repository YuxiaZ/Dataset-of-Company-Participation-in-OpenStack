#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
# import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2

version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='zhangyuxia23',
                       db='openstack_sourcecode', charset='utf8')
cursor = conn.cursor()


# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            dataList.append(tmpList)
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList


# 变换数据格式
def change_formate(dataset):
    temp = []
    for i in range(len(dataset)):
        if len(dataset[i]) == 1:
            if "." in dataset[i][0]:
                value = float(dataset[i][0])
            else:
                value = int(dataset[i][0])
            print value
        else:
            value = []
            for j in range(len(dataset[i])):
                if dataset[i][j].isdigit():
                    if "." in dataset[i][j]:
                        value.append(float(dataset[i][j]))
                    else:
                        value.append(int(dataset[i][j]))
                else:
                    value.append(dataset[i][j])
        temp.append(value)
    return temp


def extract_data(data, index):
    value = []
    for i in range(len(data)):
        value.append([data[i][index]])
    return value


sample_coms = readListCSV(path2 + "/data/sample_coms.csv")
print sample_coms

start_time = datetime.date(datetime.strptime('2016-04-07', '%Y-%m-%d'))
end_time = datetime.date(datetime.strptime('2016-10-06', '%Y-%m-%d'))

sample_commits_repo = []
for i in range(len(sample_coms)):
    print 'sample_coms', sample_coms[i][0]
    cursor.execute("SELECT repositories.name, count(scmlog.id) "
                   "FROM scmlog, commits_lines, repositories "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company like %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "group by repositories.name "
                   "order by count(scmlog.id) desc",
                   (start_time, end_time, sample_coms[i][0]))
    res = cursor.fetchall()
    sample_commits_repo.append([sample_coms[i][0], res])

print 'sample_commits_repo', sample_commits_repo

sample_devp_repo = []
for i in range(len(sample_coms)):
    print 'sample_coms', sample_coms[i][0]
    cursor.execute("SELECT repositories.name, count(distinct scmlog.author_id) "
                   "FROM scmlog, commits_lines, repositories "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company like %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "group by repositories.name "
                   "order by count(distinct scmlog.author_id) desc",
                   (start_time, end_time, sample_coms[i][0]))
    res = cursor.fetchall()
    sample_devp_repo.append([sample_coms[i][0], res])
print 'sample_devp_repo', sample_devp_repo

sample_commits_type = []
for i in range(len(sample_coms)):
    print 'sample_coms', sample_coms[i][0]
    cursor.execute("SELECT project_type.type, count(scmlog.id) "
                   "FROM scmlog, commits_lines, repositories, project_type "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company like %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null "
                   "and repositories.new_type = project_type.id "
                   "group by repositories.new_type "
                   "order by count(scmlog.id) desc",
                   (start_time, end_time, sample_coms[i][0]))
    res = cursor.fetchall()
    sample_commits_type.append([sample_coms[i][0], res])
print 'sample_commits_type', sample_commits_type

sample_devp_type = []
for i in range(len(sample_coms)):
    print 'sample_coms', sample_coms[i][0]
    cursor.execute("SELECT project_type.type, count(distinct scmlog.author_id) "
                   "FROM scmlog, commits_lines, repositories, project_type "
                   "where date between %s and %s "
                   "and message not like '    Merge %%' "
                   "and company like %s "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null "
                   "and repositories.new_type = project_type.id "
                   "group by repositories.new_type "
                   "order by count(distinct scmlog.author_id) desc",
                   (start_time, end_time, sample_coms[i][0]))
    res = cursor.fetchall()
    sample_devp_type.append([sample_coms[i][0], res])
print 'sample_devp_type', sample_devp_type


def write_data(fileName="", dataList=[]):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in dataList:
            data = [unicode(s).encode("utf-8") for s in data]
            csvWriter.writerow(data)
        csvFile.close

write_data(path2 + "/data/sample/sample_commits_repo.csv", sample_commits_repo)
write_data(path2 + "/data/sample/sample_commits_type.csv", sample_commits_repo)
write_data(path2 + "/data/sample/sample_devp_repo.csv", sample_commits_repo)
write_data(path2 + "/data/sample/sample_devp_type.csv", sample_commits_repo)


def pie(coms, title):
    labels = []
    quants = []
    others = 0
    num_other = 0
    print 'coms', coms
    for i in range(len(coms)):
        if i < 9:
            labels.append(coms[i][0])
            quants.append(coms[i][1])
        else:
            others += int(coms[i][1])
            num_other += 1
    if num_other != 0:
        quants.append(others)
        labels.append(('others (#: ' + str(num_other) + ')'))
    print 'quants: ', quants
    print 'labels: ', labels
    # make a square figure
    plt.figure(1, figsize=(8, 8))
    plt.pie(quants, labels=labels)
    plt.title(title)
    path = path2 + "/figure/sample/" + title + ".png"
    plt.savefig(path)
    plt.show()


for h in range(len(sample_coms)):
    pie(sample_commits_repo[h][1], 'The distribution of ' + sample_commits_repo[h][0]
        + '\'s commits in different repostories')
    pie(sample_commits_type[h][1], 'The distribution of ' + sample_commits_type[h][0]
        + '\'s commits in different type of repostories')
    pie(sample_devp_repo[h][1], 'The distribution of ' + sample_commits_repo[h][0]
        + '\'s developers in different repostories')
    pie(sample_devp_type[h][1], 'The distribution of ' + sample_devp_type[h][0]
        + '\'s developers in different type of repostories')






'''
coms_commits = readListCSV(path2 + "/data/coms_commits.csv")
coms_commits = change_formate(coms_commits)
coms_commits_value = np.array(extract_data(coms_commits, 1))
coms_commits_coms = np.array(extract_data(coms_commits, 0))

coms_manpower = readListCSV(path2 + "/data/coms_manpower.csv")
coms_manpower = change_formate(coms_manpower)
coms_manpower_value = np.array(extract_data(coms_manpower, 1))
coms_manpower_coms = np.array(extract_data(coms_manpower, 0))

print 'coms_commits_value:', coms_commits_value
print 'coms_manpower_value:', coms_manpower_value
print 'coms_commits_coms:', coms_commits_coms
print 'coms_manpower_coms:', coms_manpower_coms


def plot_hist(data, title, xlabel, ylabel, bins):
    # plt.figure(figsize=(6, 4))
    hist, bins = np.histogram(data, bins=bins)
    width = np.diff(bins)
    center = (bins[:-1] + bins[1:]) / 2

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(center, hist, align='center', width=width)
    ax.set_xticks(bins)
    #fig.savefig("/tmp/out.png") fix
    #plt.hist(data, bins, alpha=0.5)
    fig.title = title
    fig.xlabel = xlabel
    fig.ylabel = ylabel
    path = path2 + "/figure/" + title + ".png"
    fig.savefig(path)
    plt.show()
bins_commit = [0, 1000, 10000, 20000, 60000]
plot_hist(coms_commits_value, 'Hist of commits contributed by the companies', 'Commits',
          'Count', bins_commit)
bins_commit = [0, 50, 100, 500, 2000]
plot_hist(coms_manpower_value, 'Hist of manpower contributed by the companies', 'Manpower', 'Count', bins_commit)






'''
conn.commit()
cursor.close()
conn.close()
