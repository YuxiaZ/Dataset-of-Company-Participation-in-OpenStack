#!/usr/bin/python
# -*- coding: UTF-8 -*-
from __future__ import division
import string
from datetime import datetime
from numpy import *
import matplotlib.pyplot as plt
import numpy as np
import pymysql
import statsmodels.formula.api as smf
from numpy import mean, median
import pandas as pd
import math
import csv
import os
import sys

reload(sys)
sys.setdefaultencoding('utf8')

path1 = os.path.abspath('.')  # 表示当前所处的文件夹的绝对路径
path2 = os.path.abspath('..')  # 表示当前所处的文件夹上一级文件夹的绝对路径
print 'path2', path2
version = range(1, 15)
print 'version: ', version

conn = pymysql.connect(host='127.0.0.1', port=3306, user='amy', passwd='123456', db='FSE', charset='utf8')
cursor = conn.cursor()


version_date = ['2010-04-05', '2010-10-21', '2011-02-03', '2011-04-15', '2011-09-22', '2012-04-05', '2012-09-27',
                '2013-04-04', '2013-10-17', '2014-04-17', '2014-10-16', '2015-04-30', '2015-10-16', '2016-04-07',
                '2016-10-06', '2017-02-22']


def write_data(fileName="", dataList=[]):
    with open(fileName, "wb") as csvFile:
        csvWriter = csv.writer(csvFile)
        for data in dataList:
            data = [unicode(s).encode("utf-8") for s in data]
            csvWriter.writerow(data)
        csvFile.close

# write_data(path2 + "/data/dashboard/comslist.csv", comslist)


# 加载数据
# 功能：从文本文件中读取返回为列表的形式
# 输入：文件名称，分隔符（默认,）
def readListCSV(fileName="", splitsymbol=","):
    dataList = []
    with open(fileName, "r") as csvFile:
        dataLine = csvFile.readline().strip("\n")
        while dataLine != "":
            tmpList = dataLine.split(splitsymbol)
            dataList.append(tmpList)
            dataLine = csvFile.readline().strip("\n")
        csvFile.close()
    return dataList


def extra_date(num1, num2, re):
    if num1 > 0:
        re.append(num1/num2)
    return re


cursor.execute("SELECT * FROM com_model ")
coms_list = cursor.fetchall()
print 'coms_list', coms_list

'''
intensity = []
extent = []
interest_repo = []
interest_repoT = []
for i in range(len(coms_list)):
    print '#################', coms_list[i][0], '#################'
    iy_perV_whole_cmt = []
    iy_perV_whole_dvp = []
    iy_perV_repo_cmt = []
    iy_perV_repo_dvp = []
    iy_perV_repoT_cmt = []
    iy_perV_repoT_dvp = []
    et_perV_repo = []
    et_perV_repoT = []

    ci_repo_name = []
    ci_repo_value = []
    ci_repoT_name = []
    ci_repoT_value = []

    for j in range(14):
        start_time = datetime.date(datetime.strptime(version_date[j], '%Y-%m-%d'))
        end_time = datetime.date(datetime.strptime(version_date[j + 1], '%Y-%m-%d'))
        print start_time, end_time
        # 计算公司对整个openstack的贡献力度
        cursor.execute("SELECT count(distinct scmlog.id), count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null ", (coms_list[i][0], start_time, end_time))
        res1 = cursor.fetchall()
        if len(res1) == 0:
            continue
        cursor.execute("SELECT count(distinct scmlog.id), count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null ", (start_time, end_time))
        res2 = cursor.fetchall()
        iy_perV_whole_cmt = extra_date(res1[0][0], res2[0][0], iy_perV_whole_cmt)
        iy_perV_whole_dvp = extra_date(res1[0][1], res2[0][1], iy_perV_whole_dvp)

        print 'iy_perV_whole_cmt', iy_perV_whole_cmt
        print 'iy_perV_whole_dvp', iy_perV_whole_dvp

        # 计算公司对特定openstack repo的贡献力度
        cursor.execute("SELECT repository_id, count(distinct scmlog.id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null "
                       "group by repository_id "
                       "order by count(distinct scmlog.id) desc ", (coms_list[i][0], start_time, end_time))
        res3 = cursor.fetchall()

        if len(res3) > 0:
            cursor.execute("SELECT count(distinct scmlog.id) "
                           "FROM scmlog, commits_lines, repositories "
                           "where repository_id = %s "
                           "and message not like '    Merge %%' "
                           "and date between %s and %s "
                           "and scmlog.id = commits_lines.commit_id "
                           "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                           "and repository_id = repositories.id "
                           "and repositories.new_type is not null ", (res3[0][0], start_time, end_time))
            res4 = cursor.fetchall()

            iy_perV_repo_cmt = extra_date(res3[0][1], res4[0][0], iy_perV_repo_cmt)
        print 'iy_perV_repo_cmt', iy_perV_repo_cmt

        cursor.execute("SELECT repository_id, count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null "
                       "group by repository_id "
                       "order by count(distinct scmlog.id) desc ", (coms_list[i][0], start_time, end_time))
        res5 = cursor.fetchall()
        if len(res5) > 0:
            cursor.execute("SELECT count(distinct scmlog.author_id) "
                           "FROM scmlog, commits_lines, repositories "
                           "where repository_id = %s "
                           "and message not like '    Merge %%' "
                           "and date between %s and %s "
                           "and scmlog.id = commits_lines.commit_id "
                           "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                           "and repository_id = repositories.id "
                           "and repositories.new_type is not null ", (res5[0][0], start_time, end_time))
            res6 = cursor.fetchall()

            iy_perV_repo_dvp = extra_date(res5[0][1], res6[0][0], iy_perV_repo_dvp)
        print 'iy_perV_repo_dvp', iy_perV_repo_dvp

        # 计算公司对特定openstack repo type的贡献力度
        cursor.execute("SELECT repositories.new_type, count(distinct scmlog.id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null "
                       "group by repositories.new_type "
                       "order by count(distinct scmlog.id) desc ", (coms_list[i][0], start_time, end_time))
        res7 = cursor.fetchall()
        if len(res7) > 0:
            cursor.execute("SELECT count(distinct scmlog.id) "
                           "FROM scmlog, commits_lines, repositories "
                           "where repositories.new_type = %s "
                           "and message not like '    Merge %%' "
                           "and date between %s and %s "
                           "and scmlog.id = commits_lines.commit_id "
                           "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                           "and repository_id = repositories.id "
                           "and repositories.new_type is not null ", (res7[0][0], start_time, end_time))
            res8 = cursor.fetchall()

            iy_perV_repoT_cmt = extra_date(res7[0][1], res8[0][0], iy_perV_repoT_cmt)
        print 'iy_perV_repoT_cmt', iy_perV_repoT_cmt

        cursor.execute("SELECT repositories.new_type, count(distinct scmlog.author_id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null "
                       "group by repositories.new_type "
                       "order by count(distinct scmlog.author_id) desc ", (coms_list[i][0], start_time, end_time))
        res9 = cursor.fetchall()
        if len(res9) > 0:
            cursor.execute("SELECT count(distinct scmlog.author_id) "
                           "FROM scmlog, commits_lines, repositories "
                           "where repositories.new_type = %s "
                           "and message not like '    Merge %%' "
                           "and date between %s and %s "
                           "and scmlog.id = commits_lines.commit_id "
                           "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                           "and repository_id = repositories.id "
                           "and repositories.new_type is not null ", (res9[0][0], start_time, end_time))
            res10 = cursor.fetchall()

            iy_perV_repoT_dvp = extra_date(res9[0][1], res10[0][0], iy_perV_repoT_dvp)
        print 'iy_perV_repoT_dvp', iy_perV_repoT_dvp

        # 计算公司对项目做贡献的广度
        cursor.execute("SELECT count(distinct repository_id), count(distinct repositories.new_type) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null ", (coms_list[i][0], start_time, end_time))
        res11 = cursor.fetchall()

        cursor.execute("SELECT count(distinct repository_id), count(distinct repositories.new_type) "
                       "FROM scmlog, commits_lines, repositories "
                       "where message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null ", (start_time, end_time))
        res12 = cursor.fetchall()

        et_perV_repo = extra_date(res11[0][0], res12[0][0], et_perV_repo)
        et_perV_repoT = extra_date(res11[0][1], res12[0][1], et_perV_repoT)
        print 'et_perV_repo', et_perV_repo
        print 'et_perV_repoT', et_perV_repoT

        # 计算在项目粒度上的贡献兴趣
        cursor.execute("SELECT repositories.name, count(distinct scmlog.id) "
                       "FROM scmlog, commits_lines, repositories "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type is not null "
                       "group by repositories.name "
                       "order by count(distinct scmlog.id) desc ", (coms_list[i][0], start_time, end_time))
        res13 = cursor.fetchall()
        print 'interest repo ', res13
        if len(res13) > 0:
            for r in range(int(len(res13)*0.1)):
                if res13[r][0] in ci_repo_name:
                    ci_repo_value[ci_repo_name.index(res13[r][0])] += 1
                else:
                    ci_repo_name.append(res13[r][0])
                    ci_repo_value.append(1)

        # 计算在类型粒度上的贡献兴趣
        cursor.execute("SELECT project_type.type, count(distinct scmlog.id) "
                       "FROM scmlog, commits_lines, repositories, project_type "
                       "where company like %s "
                       "and message not like '    Merge %%' "
                       "and date between %s and %s "
                       "and scmlog.id = commits_lines.commit_id "
                       "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                       "and repository_id = repositories.id "
                       "and repositories.new_type = project_type.id "
                       "group by project_type.type "
                       "order by count(distinct scmlog.id) desc ", (coms_list[i][0], start_time, end_time))
        res14 = cursor.fetchall()
        print 'interest repoT ', res14
        if len(res14) > 0:
            for r in range(int(len(res14)*0.1)):
                if res14[r][0] in ci_repoT_name:
                    ci_repoT_value[ci_repoT_name.index(res14[r][0])] += 1
                else:
                    ci_repoT_name.append(res14[r][0])
                    ci_repoT_value.append(1)


    intensity.append([mean(iy_perV_whole_cmt), mean(iy_perV_whole_dvp),
                      median(iy_perV_whole_cmt), median(iy_perV_whole_dvp),
                      mean(iy_perV_repo_cmt), mean(iy_perV_repo_dvp),
                      median(iy_perV_repo_cmt), median(iy_perV_repo_dvp),
                      mean(iy_perV_repoT_cmt), mean(iy_perV_repoT_dvp),
                      median(iy_perV_repoT_cmt), median(iy_perV_repoT_dvp)])

    extent.append([mean(et_perV_repo), mean(et_perV_repoT), median(et_perV_repo),
                   median(et_perV_repoT)])

    interest_repo.append([ci_repo_name, ci_repo_value])
    interest_repoT.append([ci_repoT_name, ci_repoT_value])

print 'intensity: ', intensity
print 'extent: ', extent
print 'interest_repo: ', interest_repo
print 'interest_repoT: ', interest_repoT

write_data(path2 + "/data/dashboard/intensity3.csv", intensity)
write_data(path2 + "/data/dashboard/extent3.csv", extent)
write_data(path2 + "/data/dashboard/interest_repo3.csv", interest_repo)
write_data(path2 + "/data/dashboard/interest_repoT3.csv", interest_repoT)
'''
intensity = readListCSV(path2 + "/data/dashboard/intensity3.csv")
extent = readListCSV(path2 + "/data/dashboard/extent3.csv")
interest_repo = readListCSV(path2 + "/data/dashboard/interest_repo3.csv")
interest_repoT = readListCSV(path2 + "/data/dashboard/interest_repoT3.csv")

csv_reader = csv.reader(open(path2 + "/data/dashboard/intensity3.csv"))
print 'csv_reader', csv_reader

#intensity = np.loadtxt(path2 + "/data/dashboard/intensity3.csv", dtype=np.float, delimiter=",")
#extent = np.loadtxt(path2 + "/data/dashboard/extent3.csv", dtype=np.float, delimiter=",")
# interest_repo = np.loadtxt(path2 + "/data/dashboard/interest_repo3.csv", dtype=np.str, delimiter=",")
# interest_repoT = np.loadtxt(path2 + "/data/dashboard/interest_repoT3.csv", dtype=np.str, delimiter=",")

print len(intensity)
print 'intensity', intensity
print 'extent', extent
print 'interest_repo', interest_repo
print 'interest_repoT', interest_repoT
print intensity[85:88]
print intensity[85:88][0:3][0]
'''
# 对获取的结果进行处理
index = [35, 68, 85, 88, 92, 99]
mean_intensity = []
median_intensity = []
mean_extent = []
median_extent = []
M1_in_repo = []
M1_in_repoT = []
M2_in_repo = []
M2_in_repoT = []
M3_in_repo = []
M3_in_repoT = []
M4_in_repo = []
M4_in_repoT = []
M5_in_repo = []
M5_in_repoT = []
M6_in_repo = []
M6_in_repoT = []
interest_repoT_name = []
interest_repoT_value = []
# 处理贡献深度
m1 = []
m2 = []
m3 = []
m4 = []
m5 = []
m6 = []
for i in range(12):
    m1.append(median(intensity[0:35][i]))
    m2.append(median(intensity[35:68][i]))
    m3.append(median(intensity[68:85][i]))
    m4.append(median(intensity[85:88][i]))
    m5.append(median(intensity[88:92][i]))
    m6.append(median(intensity[92:99][i]))

median_intensity.append(m1)
median_intensity.append(m2)
median_intensity.append(m3)
median_intensity.append(m4)
median_intensity.append(m5)
median_intensity.append(m6)
# 处理贡献广度
m1 = []
m2 = []
m3 = []
m4 = []
m5 = []
m6 = []
for i in range(4):
    m1.append(median(intensity[0:35][i]))
    m2.append(median(intensity[35:68][i]))
    m3.append(median(intensity[68:85][i]))
    m4.append(median(intensity[85:88][i]))
    m5.append(median(intensity[88:92][i]))
    m6.append(median(intensity[92:99][i]))

median_extent.append(m1)
median_extent.append(m2)
median_extent.append(m3)
median_extent.append(m4)
median_extent.append(m5)
median_extent.append(m6)
'''
# 处理贡献兴趣

M1_in_repo = []
M1_in_repoT = []
M2_in_repo = []
M2_in_repoT = []
M3_in_repo = []
M3_in_repoT = []
M4_in_repo = []
M4_in_repoT = []
M5_in_repo = []
M5_in_repoT = []
M6_in_repo = []
M6_in_repoT = []
interest_repoT_name = []
interest_repoT_value = []


def interest(dt=[]):
    name = []
    value = []
    for i in range(len(dt)):
        if dt[i][0] in name:
            value[name.index(dt[i][0])] += 1
        else:
            name.append(dt[i][0])
            value.append(1)
    return name, value

name, value = interest(interest_repo[0:35])
M1_in_repo.append([name, value])
name, value = interest(interest_repoT[0:35])
M1_in_repoT.append([name, value])

name, value = interest(interest_repo[35:68])
M2_in_repo.append([name, value])
name, value = interest(interest_repoT[35:68])
M2_in_repoT.append([name, value])

name, value = interest(interest_repo[68:85])
M3_in_repo.append([name, value])
name, value = interest(interest_repoT[68:85])
M3_in_repoT.append([name, value])

name, value = interest(interest_repo[85:88])
M4_in_repo.append([name, value])
name, value = interest(interest_repoT[85:88])
M4_in_repoT.append([name, value])

name, value = interest(interest_repo[88:92])
M5_in_repo.append([name, value])
name, value = interest(interest_repoT[88:92])
M5_in_repoT.append([name, value])

name, value = interest(interest_repo[92:99])
M6_in_repo.append([name, value])
name, value = interest(interest_repoT[92:99])
M6_in_repoT.append([name, value])


#write_data(path2 + "/data/dashboard/median_intensity.csv", median_intensity)
#write_data(path2 + "/data/dashboard/median_extent.csv", median_extent)

write_data(path2 + "/data/dashboard/M1_in_repo.csv", M1_in_repo)
write_data(path2 + "/data/dashboard/M1_in_repoT.csv", M1_in_repoT)

write_data(path2 + "/data/dashboard/M2_in_repo.csv", M2_in_repo)
write_data(path2 + "/data/dashboard/M2_in_repoT.csv", M2_in_repoT)

write_data(path2 + "/data/dashboard/M3_in_repo.csv", M3_in_repo)
write_data(path2 + "/data/dashboard/M3_in_repoT.csv", M3_in_repoT)

write_data(path2 + "/data/dashboard/M4_in_repo.csv", M4_in_repo)
write_data(path2 + "/data/dashboard/M4_in_repoT.csv", M4_in_repoT)

write_data(path2 + "/data/dashboard/M5_in_repo.csv", M5_in_repo)
write_data(path2 + "/data/dashboard/M5_in_repoT.csv", M5_in_repoT)

write_data(path2 + "/data/dashboard/M6_in_repo.csv", M6_in_repo)
write_data(path2 + "/data/dashboard/M6_in_repoT.csv", M6_in_repoT)


'''


cursor.execute("SELECT repositories.name "
               "FROM scmlog, commits_lines, repositories "
               "where message not like '    Merge %%' "
               "and scmlog.id = commits_lines.commit_id "
               "and (commits_lines.added != 0 or commits_lines.removed != 0) "
               "and repository_id = repositories.id "
               "and repositories.new_type is not null "
               "group by repositories.name "
               "order by count(distinct scmlog.author_id) desc ")
repo_list = cursor.fetchall()

cursor.execute("SELECT project_type.type "
               "FROM project_type ")
repoT_list = cursor.fetchall()

print 'repo', repo_list
print 'len(repo)', len(repo_list)
print 'repoT', repoT_list

repoT1 = [0]*15
repoT2 = [0]*15
repoT3 = [0]*15
repoT4 = [0]*15
repoT5 = [0]*15


def gather(re, tu):
    print '@@@@@@@@@@@@@@'
    for j in range(len(re)):
        print '**********re[i][0]', re[j][0]
        tu[re[j][0]-1] += 1
    return tu

for i in range(len(coms_list)):
    cursor.execute("SELECT distinct repositories.new_type "
                   "FROM scmlog, commits_lines, repositories "
                   "where company like %s "
                   "and message not like '    Merge %%' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null ", coms_list[i][0])
    res = cursor.fetchall()
    print res
    print '**************coms_list[i][1]', coms_list[i][1]
    if coms_list[i][1] == '1':
        print '*************'
        repoT1 = gather(res, repoT1)
    if coms_list[i][1] == '2':
        repoT2 = gather(res, repoT2)
    if coms_list[i][1] == '3':
        repoT3 = gather(res, repoT3)
    if coms_list[i][1] == '4':
        repoT4 = gather(res, repoT4)
    if coms_list[i][1] == '5':
        repoT5 = gather(res, repoT5)

print 'repoT1', repoT1
print 'repoT2', repoT2
print 'repoT3', repoT3
print 'repoT4', repoT4
print 'repoT5', repoT5

write_data(path2 + "/data/dashboard/model1_prefer_repoT.csv", repoT1)
write_data(path2 + "/data/dashboard/model2_prefer_repoT.csv", repoT2)
write_data(path2 + "/data/dashboard/model3_prefer_repoT.csv", repoT3)
write_data(path2 + "/data/dashboard/model4_prefer_repoT.csv", repoT4)
write_data(path2 + "/data/dashboard/model5_prefer_repoT.csv", repoT5)


# 获取每种类型公司最常参与的repo
repo1 = [0]*540
repo2 = [0]*540
repo3 = [0]*540
repo4 = [0]*540
repo5 = [0]*540

for i in range(len(coms_list)):
    cursor.execute("SELECT repository_id "
                   "FROM scmlog, commits_lines, repositories "
                   "where company like %s "
                   "and message not like '    Merge %%' "
                   "and scmlog.id = commits_lines.commit_id "
                   "and (commits_lines.added != 0 or commits_lines.removed != 0) "
                   "and repository_id = repositories.id "
                   "and repositories.new_type is not null "
                   "group by repository_id "
                   "order by count(distinct scmlog.id) desc ", coms_list[i][0])
    res = cursor.fetchall()
    print 'res', res
    if 0 < len(res) < 10:
        if coms_list[i][1] == '1':
            for j in range(len(res)):
                repo1[res[j][0]] += 1
        if coms_list[i][1] == '2':
            for j in range(len(res)):
                repo2[res[j][0]] += 1
        if coms_list[i][1] == '3':
            for j in range(len(res)):
                repo3[res[j][0]] += 1
        if coms_list[i][1] == '4':
            for j in range(len(res)):
                repo4[res[j][0]] += 1
        if coms_list[i][1] == '5':
            for j in range(len(res)):
                repo5[res[j][0]] += 1
    else:
        if coms_list[i][1] == '1':
            for j in range(len(res)):
                if j < 0.2*len(res):
                    repo1[res[j][0]] += 1
        if coms_list[i][1] == '2':
            for j in range(len(res)):
                if j < 0.2*len(res):
                    repo2[res[j][0]] += 1
        if coms_list[i][1] == '3':
            for j in range(len(res)):
                if j < 0.2*len(res):
                    repo3[res[j][0]] += 1
        if coms_list[i][1] == '4':
            for j in range(len(res)):
                if j < 0.2*len(res):
                    repo4[res[j][0]] += 1
        if coms_list[i][1] == '5':
            for j in range(len(res)):
                if j < 0.2*len(res):
                    repo5[res[j][0]] += 1


print 'repo1', repo1
print 'repo2', repo2
print 'repo3', repo3
print 'repo4', repo4
print 'repo5', repo5

# write_data(path2 + "/data/dashboard/model1_prefer_repo.csv", repo1)
# write_data(path2 + "/data/dashboard/model2_prefer_repo.csv", repo2)
# write_data(path2 + "/data/dashboard/model3_prefer_repo.csv", repo3)
# write_data(path2 + "/data/dashboard/model4_prefer_repo.csv", repo4)
# write_data(path2 + "/data/dashboard/model5_prefer_repo.csv", repo5)
np.savetxt(path2 + "/data/dashboard/model1_prefer_repo.csv", repo1, fmt="%d", delimiter=",")
np.savetxt(path2 + "/data/dashboard/model2_prefer_repo.csv", repo2, fmt="%d", delimiter=",")
np.savetxt(path2 + "/data/dashboard/model3_prefer_repo.csv", repo3, fmt="%d", delimiter=",")
np.savetxt(path2 + "/data/dashboard/model4_prefer_repo.csv", repo4, fmt="%d", delimiter=",")
np.savetxt(path2 + "/data/dashboard/model5_prefer_repo.csv", repo5, fmt="%d", delimiter=",")
'''

conn.commit()
cursor.close()
conn.close()